Carved Echoes v3: 4 easy / 4 medium / 2 hard. Read START_HERE.md. Extract all folders and keep the raw image unchanged.
