# Carved Echoes version 3

10 questions: 4 easy, 4 medium, 2 hard · 72 points · six derived flags · suggested time 75–105 minutes

Investigate a generated MBR/FAT16 USB image. Verify its integrity, locate the deleted invoice, recover dispatch material, inspect slack, then explain the authenticated archive transfer.

Integrity → partition → deleted entry → cluster size → invoice recovery → photograph → release PDF → slack → archive decoding → transfer timeline.

One hint per question. Answers ignore case and all whitespace; punctuation and component order must match the format. All scenario timestamps are UTC. Keep original evidence read-only.
