# Carved Echoes investigation questions

Current balanced edition · updated 16 November 2026

10 questions: 4 easy, 4 medium, 2 hard · 72 points.

Use the original Evidence/Disk/evidence_usb.img read-only. Save exports in Working. Answers ignore case and whitespace; punctuation and component order must match.

## Q1 — Check that the disk image is unchanged (easy; 5 points)

The evidence file is Evidence/Disk/evidence_usb.img. Calculate its SHA-256 hash.  
Compare the full hash with the image entry in Hashes/SHA256SUMS.txt.  
If they match, submit the first 16 characters of the image hash. Do not hash the ZIP.

**Tool to be used:** SHA-256 utility + text viewer

**Answer format:** `<first16_sha256>`

**Hint:** Use sha256sum on the IMG. Copy characters 1–16 from its hash, not from its filename.

## Q2 — Find where the FAT16 partition starts (easy; 5 points)

Run mmls on Evidence/Disk/evidence_usb.img to view its partition table.  
Find the FAT16 row and read the number in its Start column.  
Submit that sector number. You will use it after -o in later Sleuth Kit commands.

**Tool to be used:** Sleuth Kit mmls

**Answer format:** `<start_sector>`

**Hint:** Select the FAT16 partition, rather than a metadata or unallocated-space row. Keep the value in sectors.

## Q3 — Find the deleted invoice file entry (easy; 5 points)

Use fls to list files inside the image, with the partition start from Q2 after -o.  
Look in DOCS for the deleted CSV invoice. An asterisk (*) marks a deleted entry.  
Submit the number before its filename and colon: this is its metadata address, used by icat.  
Read the number from the listing; you do not need to calculate it or submit the filename.

**Tool to be used:** Sleuth Kit fls

**Answer format:** `<metadata_address>`

**Hint:** Use fls -r -p to include subfolders and paths. The deleted CSV may have its first filename character replaced by _.

## Q4 — Find the number of bytes in one cluster (easy; 5 points)

Run fsstat on the image, using the partition start from Q2 after -o.  
Find the field labelled Cluster Size. A cluster is the unit used to allocate file space.  
Submit its size in bytes, not the Sector Size. Keep it for the unused-space check in Q8.

**Tool to be used:** Sleuth Kit fsstat

**Answer format:** `<cluster_size_bytes>`

**Hint:** Read the Cluster Size field directly from fsstat; no conversion or arithmetic is needed.

## Q5 — Sleuth Kit: recover and total the invoice (medium; 8 points)

Use icat -r with the Q3 file address to save the deleted invoice as Working/invoice.csv.  
Export LOGS/LEDGER.CSV too; compare the recovered invoice’s full SHA-256 with its ledger record.  
Open the invoice. For each of its three rows, multiply quantity by unit_price, then add the results.  
Submit the invoice_id shown in the file and your total, removing the hyphen from invoice_id.

**Tool to be used:** Sleuth Kit icat + sha256sum + CSV viewer/calculator

**Answer format:** `FLAG{invoice_<invoice_without_hyphen>_<total>}`

**Hint:** Use fls to find the ledger’s own file address. If the hashes match, a calculator is enough for the three item rows.

## Q6 — Find the dispatch bay and photograph time (medium; 8 points)

Use carve_lab.py scan/carve to recover a JPEG from unallocated space: disk space not assigned to a file.  
Open the recovered picture and confirm that its invoice number matches the invoice recovered in Q5.  
Read the bay printed in the picture; use jpeg-info to read DateTimeOriginal and its UTC offset.  
Submit the bay and UTC time as HHMMSS (hours, minutes, seconds, without colons).

**Tool to be used:** Supplied carve_lab.py + image viewer

**Answer format:** `FLAG{photo_<bay>_<hhmmss>}`

**Hint:** The bay is visible in the picture; the time is in EXIF metadata. Reject a broken image or one for a different invoice.

## Q7 — Autopsy: choose the correct release document (medium; 8 points)

In Autopsy, add the IMG, browse DOCS and export its existing PDF; open it to read its invoice and status.  
Use carve_lab.py scan/carve to recover a complete PDF from unallocated space, then open that PDF too.  
Choose the APPROVED document whose invoice matches Q5 and whose bay matches the Q6 photograph.  
Submit that document’s invoice identifier and release authorization, removing their hyphens.

**Tool to be used:** Autopsy + supplied carve_lab.py + PDF viewer

**Answer format:** `FLAG{release_<invoice_without_hyphen>_<authorization_without_hyphen>}`

**Hint:** Compare both PDFs, not just their filenames. The existing DOCS PDF is a comparison record; check invoice, bay and approval status.

## Q8 — Read the key hidden after the session log (medium; 8 points)

Use carve_lab.py list to find LOGS/SESSION.LOG and note its entry_offset.  
Use the helper’s slack command with that offset to save the unused bytes after the log’s end.  
Read the saved slack with strings to find xor_byte, then use wc -c to count the saved bytes.  
Submit the two hexadecimal key digits and the byte count; keep the key for Q9.

**Tool to be used:** Supplied carve_lab.py + strings + wc

**Answer format:** `FLAG{slack_<two_hex_key_digits>_<slack_bytes>}`

**Hint:** File slack is unused space at the end of the last cluster. Use entry_offset from the helper, not the fls file address.

## Q9 — Recover the ZIP and read its encoded message (hard; 10 points)

Recover the complete ZIP with carve_lab.py scan/carve; match its SHA-256 with BUNDLE-042 in the Q5 ledger.  
Extract the ZIP, then use the helper’s xor command and Q8 key to decode handoff.xor into handoff.json.  
Compare the decoded hash and byte count with manifest.json; check that invoice_id matches Q5.  
Read stage_id and fragment_tag from the verified JSON and submit them, removing the stage_id hyphen.

**Tool to be used:** Supplied carve_lab.py + unzip + sha256sum + text viewer

**Answer format:** `FLAG{decode_<stage_without_hyphen>_<fragment_tag>}`

**Hint:** The manifest lists decoded_sha256 and decoded_length. Compare them with sha256sum and wc -c before trusting the message.

## Q10 — Use the audit log to explain the transfer (hard; 10 points)

Export LOGS/AUDIT.CSV. Keep rows matching the Q9 stage_id and ZIP hash, with status OK.  
For those rows, add bytes only where action is SEND; compare the sum with the ZIP’s file size.  
Calculate seconds from the matching STAGE time to the last matching SEND time; ignore failed or unrelated rows.  
Submit Q5 invoice, Q6 bay, Q9 stage, SEND byte sum and elapsed seconds; remove identifier hyphens.

**Tool to be used:** Sleuth Kit icat + CSV viewer + calculator

**Answer format:** `FLAG{closure_<invoice>_<bay>_<stage>_<sent_bytes>_<elapsed_seconds>}`

**Hint:** A CSV viewer and calculator are enough. Start at STAGE, end at the final successful SEND, and use the exact ZIP hash.
