# Kali tool reference

Work in the extracted folder containing Evidence, Hashes and carve_lab.py. Start Bash with `bash`, then create exports with `mkdir -p Working`. DOCS and LOGS are inside the image, not folders on your desktop. Keep the original image unchanged.

Run one command at a time. Values in CAPITALS below are values you discover and replace, not text to paste unchanged. The questions require interpreting outputs and comparing records; no long scripts are required.

## Q1 — Image integrity

```bash
sha256sum Evidence/Disk/evidence_usb.img
cat Hashes/SHA256SUMS.txt
```

Compare full digests, then take the first 16 characters of the matching image digest.

## Q2 — Partition

```bash
mmls Evidence/Disk/evidence_usb.img
```

Read Start for the FAT16 row. Use this discovered number wherever SECTOR appears below.

## Q3 — Deleted entry

```bash
fls -r -p -o SECTOR Evidence/Disk/evidence_usb.img
```

An asterisk marks deletion. The number before the filename is its metadata address, used by icat. Record the deleted CSV address and the allocated ledger and audit addresses for later exports.

## Q4 — Cluster size

```bash
fsstat -o SECTOR Evidence/Disk/evidence_usb.img
```

Read Cluster Size, not Sector Size.

## Q5 — Invoice

```bash
icat -r -o SECTOR Evidence/Disk/evidence_usb.img INVOICE_ADDRESS > Working/invoice.csv
icat -o SECTOR Evidence/Disk/evidence_usb.img LEDGER_ADDRESS > Working/ledger.csv
sha256sum Working/invoice.csv
```

Open both CSV files in a CSV viewer or text editor. Compare the complete hash with the matching ledger record. Use a calculator for each quantity × unit_price product and add the three products; no awk script is needed.

## Q6 — Photograph

```bash
python3 carve_lab.py scan Evidence/Disk/evidence_usb.img --type jpeg
python3 carve_lab.py carve Evidence/Disk/evidence_usb.img --type jpeg --offset OFFSET --out Working/dispatch.jpg
python3 carve_lab.py jpeg-info Working/dispatch.jpg
xdg-open Working/dispatch.jpg
```

Choose OFFSET from a candidate in unallocated space. The image must open and match the invoice. Read the bay visually and the original timestamp plus offset from metadata; reject malformed or unrelated candidates.

## Q7 — Release

Use Autopsy to examine the same USB image before choosing the release. On Kali, the packaged Autopsy is the browser-based 2.x interface, not the Windows 4.x desktop interface:

```bash
sudo autopsy
realpath Evidence/Disk/evidence_usb.img
```

Keep Autopsy running and open the localhost URL printed by it. Create a case and host, select UTC for this case, and add the IMG using its absolute path as a disk image. Use the link/symlink import option to retain the source location. Select the FAT16 volume beginning at the Q2 sector, choose Analyze, then File Analysis. Browse DOCS, select its allocated PDF and use Export to save it in Working. Open that export in a PDF viewer and note its invoice and status.

In a second terminal in the evidence-root folder, carve the unallocated PDF candidate:

```bash
python3 carve_lab.py scan Evidence/Disk/evidence_usb.img --type pdf
python3 carve_lab.py carve Evidence/Disk/evidence_usb.img --type pdf --offset OFFSET --out Working/release.pdf
xdg-open Working/release.pdf
```

Compare both documents with the invoice from Q5 and bay from Q6. Record why the allocated record is rejected, and read the authorization from the matching approved release. A PDF header alone is insufficient. On Windows Autopsy 4.x, add the raw image as Disk Image or VM File and browse the filesystem under Data Sources; use Extract File for the allocated PDF. The recovered PDF can be added separately as Logical Files if desired.

Tool references: [Kali Autopsy package](https://www.kali.org/tools/autopsy/), [Autopsy 2 file analysis and export](https://sleuthkit.org/autopsy/help/file_mode.html). This route is documentation-checked; live Autopsy GUI execution has not been validated in this workspace.

## Q8 — File slack

```bash
python3 carve_lab.py list Evidence/Disk/evidence_usb.img
python3 carve_lab.py slack Evidence/Disk/evidence_usb.img --entry ENTRY_OFFSET --out Working/session.slack
strings -a Working/session.slack
wc -c < Working/session.slack
```

Use the SESSION.LOG entry_offset from list. It is a byte offset, different from the metadata address displayed by fls. The slack utility follows the real cluster chain for you. Read xor_byte and the extracted byte count.

## Q9 — Archive

```bash
python3 carve_lab.py scan Evidence/Disk/evidence_usb.img --type zip
python3 carve_lab.py carve Evidence/Disk/evidence_usb.img --type zip --offset OFFSET --out Working/handoff.zip
sha256sum Working/handoff.zip
unzip -o Working/handoff.zip -d Working/archive
```

Compare the archive digest with BUNDLE-042 in the exported ledger; extraction must report no CRC errors. Then replace KEY with the two hexadecimal digits found in Q8:

```bash
python3 carve_lab.py xor Working/archive/handoff.xor --key KEY --out Working/handoff.json
sha256sum Working/handoff.json
wc -c < Working/handoff.json
```

Open handoff.json and manifest.json in a text viewer. Match the decoded digest, length and invoice identity before reading stage_id and fragment_tag.

## Q10 — Transfer analysis

```bash
icat -o SECTOR Evidence/Disk/evidence_usb.img AUDIT_ADDRESS > Working/audit.csv
xdg-open Working/audit.csv
```

Use your CSV viewer's filter, or inspect the small table in a text editor. Match stage_id, exact object_sha256 and status OK. Add bytes only for SEND rows; compare with the archive size in file properties. Use a calculator for the interval from matching STAGE to the last matching SEND. Combine this result with the invoice, bay and stage established earlier. No shell loop or long filter script is necessary.
