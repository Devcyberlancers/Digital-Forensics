# Carved Echoes version 3

10 questions: 4 easy, 4 medium, 2 hard · 72 points · six derived flags · suggested time 75–105 minutes

Investigate a generated MBR/FAT16 USB image. Verify its integrity, locate the deleted invoice, recover dispatch material, inspect slack, then explain the authenticated archive transfer.

## Layout and tools

Extract the entire student release, then open WebApp/index.html. Evidence paths in questions start inside Student_VM/DFIR_CTF_Machine08. If using only Student_Evidence_Files.zip, its extraction root already contains Evidence, Hashes, Tools_Guide and carve_lab.py.

- Windows primary: FTK Imager (add Image File, not Folder Contents), PowerShell, a hex viewer, JPEG/PDF viewers, ZIP tools and Python 3 for the supplied recovery utility. ExifTool is recommended for image metadata.
- Kali primary: Bash, Sleuth Kit (mmls/fls/icat), Python 3, sha256sum, strings/xxd, ExifTool, PDF viewer or pdftotext, and unzip. Foremost/Scalpel may be used for carving; validate their output and exact hashes.
- FTK Imager's Windows graphical route is not promised as a native Kali application. Kali has a documented Sleuth Kit route for the same raw evidence.
- The supplied carve_lab.py uses Python's standard library only. It lists filesystem metadata, exports selected entries, follows FAT chains, extracts slack, scans/carves signatures and slices/joins bytes you choose. It does not select case answers or print flags. Independent tools are encouraged; capture FTK/TSK output for your notebook.

## Start in the evidence root

Kali: run bash, then cd Student_VM/DFIR_CTF_Machine08 from the extracted release root.
Windows: Set-Location Student_VM/DFIR_CTF_Machine08.
From an evidence-only extraction, stay at its root instead. Do not start inside Evidence itself.

Create a Working directory OUTSIDE Evidence. Never mount this image writable. Commands and detailed FTK steps are in Tools_Guide/Recovery_Workflows.md. Python commands are python3 on Kali and py -3 (or your installed Python 3 command) on Windows.

Case and ALL whitespace are ignored when checking answers. Punctuation and token order must match the displayed format; blank/partial answers fail. All scenario times are UTC; FAT timestamps have 2-second precision. Record commands, source paths, absolute byte offsets, hashes and why you rejected decoys.

Deleted FAT filenames may display a missing first character. A metadata address from fls is NOT the byte offset accepted by carve_lab.py --entry. Use each tool's own displayed identifier. A signature hit is only a candidate; incomplete hits and allocated decoys are intentional. File slack is beyond logical EOF in the final allocated cluster, not a separately supplied text file.
