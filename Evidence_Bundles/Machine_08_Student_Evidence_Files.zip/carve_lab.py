#!/usr/bin/env python3
"""Read-only FAT16 and byte-recovery utilities. These commands do not solve the case."""
import argparse
import io
import json
from pathlib import Path
import struct
import zipfile

def u16(data, offset): return struct.unpack_from('<H', data, offset)[0]
def u32(data, offset): return struct.unpack_from('<I', data, offset)[0]

class Disk:
    def __init__(self, data):
        self.data=data
        if data[510:512]!=b'\x55\xaa': raise ValueError('Missing MBR signature')
        self.start=u32(data,454); self.base=self.start*512
        b=self.base
        self.sector=u16(data,b+11); self.spc=data[b+13]; self.reserved=u16(data,b+14)
        self.fats=data[b+16]; self.root_count=u16(data,b+17); self.fat_sectors=u16(data,b+22)
        self.total=u16(data,b+19) or u32(data,b+32)
        self.root_sectors=(self.root_count*32+self.sector-1)//self.sector
        self.fat_offset=b+self.reserved*self.sector
        self.root_offset=b+(self.reserved+self.fats*self.fat_sectors)*self.sector
        self.data_offset=self.root_offset+self.root_sectors*self.sector
        self.cluster_bytes=self.sector*self.spc
        self.cluster_count=(self.total-self.reserved-self.fats*self.fat_sectors-self.root_sectors)//self.spc
        if not 4085<=self.cluster_count<65525: raise ValueError('This reader supports FAT16 only')
        if data[b+510:b+512]!=b'\x55\xaa':raise ValueError('Missing volume boot signature')
    def offset(self, cluster):
        if not 2<=cluster<self.cluster_count+2:raise ValueError('Cluster outside volume')
        return self.data_offset+(cluster-2)*self.cluster_bytes
    def fat(self, cluster):return u16(self.data,self.fat_offset+cluster*2)
    def chain(self, cluster):
        result=[]
        while 2<=cluster<0xfff8:
            if cluster in result:raise ValueError('FAT loop')
            self.offset(cluster);result.append(cluster);cluster=self.fat(cluster)
            if cluster==0:break
        return result
    def entry(self, offset):
        e=self.data[offset:offset+32]
        if len(e)!=32 or e[0] in (0,):raise ValueError('No directory entry here')
        name=e[:8].decode('ascii','replace').rstrip();ext=e[8:11].decode('ascii','replace').rstrip()
        if e[0]==0xe5:name='?'+name[1:]
        return dict(name=name+('.'+ext if ext else ''),entry_offset=offset,deleted=e[0]==0xe5,
                    directory=bool(e[11]&0x10),attribute=e[11],first_cluster=u16(e,26),size=u32(e,28))
    def entries(self):
        seen=set()
        def visit(data_start,length,parent):
            for pos in range(data_start,data_start+length,32):
                raw=self.data[pos:pos+32]
                if raw[0]==0:break
                if raw[11]==0x0f or raw[11]&8:continue
                entry=self.entry(pos)
                if entry['name'] in ('.','..'):continue
                entry['path']=parent+'/'+entry['name'];yield entry
                if entry['directory'] and not entry['deleted'] and entry['first_cluster'] not in seen:
                    seen.add(entry['first_cluster'])
                    for cluster in self.chain(entry['first_cluster']):yield from visit(self.offset(cluster),self.cluster_bytes,entry['path'])
        return list(visit(self.root_offset,self.root_sectors*self.sector,''))
    def recover(self, entry):
        needed=(entry['size']+self.cluster_bytes-1)//self.cluster_bytes
        # Cleared FAT chains contain no reliable next-cluster pointers.
        chain=list(range(entry['first_cluster'],entry['first_cluster']+needed)) if entry['deleted'] else self.chain(entry['first_cluster'])
        return b''.join(self.data[self.offset(c):self.offset(c)+self.cluster_bytes] for c in chain)[:entry['size']]
    def slack(self,entry):
        if entry['deleted']:raise ValueError('Slack command requires an allocated file')
        chain=self.chain(entry['first_cluster'])
        used=entry['size']-(len(chain)-1)*self.cluster_bytes
        if not 0<used<=self.cluster_bytes:raise ValueError('Size/chain mismatch')
        start=self.offset(chain[-1])+used
        return start,self.data[start:self.offset(chain[-1])+self.cluster_bytes]

def carve(data,offset,kind):
    if offset<0 or offset>=len(data):raise ValueError('Offset outside input')
    if kind=='jpeg':
        if data[offset:offset+2]!=b'\xff\xd8':raise ValueError('Not a JPEG SOI')
        pos=offset+2
        while pos<len(data):
            if data[pos]!=255:raise ValueError('Invalid JPEG marker')
            while data[pos]==255:pos+=1
            marker=data[pos];pos+=1
            if marker==0xd9:return data[offset:pos]
            if marker in (0xd8,0,0xff):raise ValueError('Invalid JPEG segment')
            length=int.from_bytes(data[pos:pos+2],'big')
            if length<2 or pos+length>len(data):raise ValueError('Invalid JPEG segment length')
            if marker==0xda:
                end=data.find(b'\xff\xd9',pos+length)
                if end<0:raise ValueError('JPEG EOI not found')
                return data[offset:end+2]
            pos+=length
        raise ValueError('Incomplete JPEG')
    if kind=='pdf':
        if data[offset:offset+5]!=b'%PDF-':raise ValueError('Not a PDF header')
        end=data.find(b'%%EOF',offset)
        if end<0:raise ValueError('PDF EOF not found')
        end+=5
        while end<len(data) and data[end] in (10,13):end+=1
        result=data[offset:end]
        if b'startxref' not in result or b'/Root' not in result:raise ValueError('Incomplete PDF structure')
        return result
    if kind=='zip':
        if data[offset:offset+4]!=b'PK\x03\x04':raise ValueError('Not a ZIP local header')
        cursor=offset
        while True:
            cursor=data.find(b'PK\x05\x06',cursor+1)
            if cursor<0:raise ValueError('No matching ZIP end record')
            if cursor+22>len(data):raise ValueError('Incomplete ZIP end record')
            size=u32(data,cursor+12);relative=u32(data,cursor+16);comment=u16(data,cursor+20)
            if offset+relative+size!=cursor:continue
            result=data[offset:cursor+22+comment]
            if len(result)!=cursor+22+comment-offset:raise ValueError('Truncated ZIP comment')
            with zipfile.ZipFile(io.BytesIO(result)) as z:
                if z.testzip() is not None:raise ValueError('ZIP CRC validation failed')
            return result
    raise ValueError('Unsupported carving type')

def write_output(destination,data):
    target=Path(destination).resolve()
    if any(p.name.lower()=='evidence' for p in (target,*target.parents)):
        raise ValueError('Write recovered files outside Evidence, for example Working/')
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    print(json.dumps({'output':str(target),'bytes_written':len(data)}))

def jpeg_info(data):
    """Inspect TIFF ASCII/Exif fields without external packages."""
    if data[:2]!=b'\xff\xd8':raise ValueError('Not a JPEG')
    pos=2
    while pos+4<len(data):
        if data[pos]!=255:raise ValueError('Invalid JPEG segment')
        marker=data[pos+1];length=int.from_bytes(data[pos+2:pos+4],'big')
        if marker==0xda:break
        if length<2:raise ValueError('Invalid segment size')
        segment=data[pos+4:pos+2+length];pos+=2+length
        if marker!=0xe1 or not segment.startswith(b'Exif\0\0'):continue
        tiff=segment[6:];order='<' if tiff[:2]==b'II' else '>'
        def short(o):return struct.unpack_from(order+'H',tiff,o)[0]
        def long(o):return struct.unpack_from(order+'I',tiff,o)[0]
        if short(2)!=42:raise ValueError('Invalid TIFF header')
        names={0x010f:'Make',0x0110:'Model',0x0132:'DateTime',0x9003:'DateTimeOriginal',0x9011:'OffsetTimeOriginal'}
        result={};visited=set()
        def visit(offset):
            if offset in visited:raise ValueError('Exif IFD loop')
            visited.add(offset)
            for i in range(short(offset)):
                p=offset+2+i*12;tag=short(p);kind=short(p+2);count=long(p+4)
                if tag==0x8769:visit(long(p+8))
                if tag in names and kind==2:
                    start=p+8 if count<=4 else long(p+8)
                    result[names[tag]]=tiff[start:start+count].rstrip(b'\0').decode('ascii','replace')
        visit(long(4));return result
    raise ValueError('Exif block not found')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    sub=p.add_subparsers(dest='command',required=True)
    for name in ['info','list','export','chain','slack','scan','carve','slice','find','hex']:
        q=sub.add_parser(name);q.add_argument('image',type=Path)
        if name in ['export','slack']:q.add_argument('--entry',type=lambda s:int(s,0),required=True);q.add_argument('--out',required=True)
        if name=='chain':q.add_argument('--first-cluster',type=int,required=True)
        if name in ['carve','slice','hex']:q.add_argument('--offset',type=lambda s:int(s,0),required=True)
        if name in ['slice','hex']:q.add_argument('--length',type=int,required=True)
        if name in ['carve','slice']:q.add_argument('--out',required=True)
        if name in ['carve','scan']:q.add_argument('--type',choices=['jpeg','pdf','zip','all'] if name=='scan' else ['jpeg','pdf','zip'],default='all' if name=='scan' else None,required=name=='carve')
        if name=='find':q.add_argument('--text',required=True)
    q=sub.add_parser('xor');q.add_argument('input',type=Path);q.add_argument('--key',required=True);q.add_argument('--out',required=True)
    q=sub.add_parser('jpeg-info');q.add_argument('input',type=Path)
    q=sub.add_parser('join');q.add_argument('parts',type=Path,nargs='+');q.add_argument('--size',type=int,required=True);q.add_argument('--out',required=True)
    a=p.parse_args()
    try:
        if a.command=='jpeg-info':print(json.dumps(jpeg_info(a.input.read_bytes()),indent=2));return
        if a.command=='xor':
            key=int(a.key,16)
            if not 0<=key<=255:raise ValueError('Key must be one hex byte')
            write_output(a.out,bytes(b^key for b in a.input.read_bytes()));return
        if a.command=='join':write_output(a.out,b''.join(part.read_bytes() for part in a.parts)[:a.size]);return
        data=a.image.read_bytes();disk=Disk(data)
        if a.command=='info':print(json.dumps({k:getattr(disk,k) for k in ['start','sector','spc','cluster_bytes','cluster_count','root_offset','data_offset']},indent=2))
        elif a.command=='list':
            for entry in disk.entries():print(json.dumps(entry))
        elif a.command=='chain':print(json.dumps([{'cluster':c,'absolute_offset':disk.offset(c),'fat_value':disk.fat(c)} for c in disk.chain(a.first_cluster)],indent=2))
        elif a.command=='export':
            entry=disk.entry(a.entry)
            if entry['directory']:raise ValueError('Select a file entry, not a directory')
            if entry['deleted']:print('CAUTION: contiguous deleted recovery is an assumption. Verify hash; fragmentation can make this wrong.')
            write_output(a.out,disk.recover(entry))
        elif a.command=='slack':
            start,slack=disk.slack(disk.entry(a.entry));print('slack_absolute_offset='+str(start));write_output(a.out,slack)
        elif a.command=='carve':write_output(a.out,carve(data,a.offset,a.type))
        elif a.command in ['slice','hex']:
            if a.offset<0 or a.length<0 or a.offset+a.length>len(data):raise ValueError('Range outside image')
            result=data[a.offset:a.offset+a.length]
            if a.command=='slice':write_output(a.out,result)
            else:print(result.hex(' '))
        elif a.command in ['scan','find']:
            signatures={'jpeg':b'\xff\xd8\xff','pdf':b'%PDF-','zip':b'PK\x03\x04'} if a.command=='scan' else {'text':a.text.encode()}
            for kind,signature in signatures.items():
                if a.command=='scan' and a.type not in ('all',kind):continue
                cursor=-1
                while True:
                    cursor=data.find(signature,cursor+1)
                    if cursor<0:break
                    cluster=(cursor-disk.data_offset)//disk.cluster_bytes+2
                    allocation='free' if 2<=cluster<disk.cluster_count+2 and disk.fat(cluster)==0 else 'allocated-or-metadata'
                    print(json.dumps({'type':kind,'absolute_offset':cursor,'cluster':cluster,'allocation':allocation}))
    except (ValueError,OSError,zipfile.BadZipFile,struct.error) as exc:p.exit(2,str(exc)+'\n')

if __name__=='__main__':main()
