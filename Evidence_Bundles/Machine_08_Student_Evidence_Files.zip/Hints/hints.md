# One progressive investigation hint per question

## Q1

Use sha256sum on the IMG. Copy characters 1–16 from its hash, not from its filename.

## Q2

Select the FAT16 partition, rather than a metadata or unallocated-space row. Keep the value in sectors.

## Q3

Use fls -r -p to include subfolders and paths. The deleted CSV may have its first filename character replaced by _.

## Q4

Read the Cluster Size field directly from fsstat; no conversion or arithmetic is needed.

## Q5

Use fls to find the ledger’s own file address. If the hashes match, a calculator is enough for the three item rows.

## Q6

The bay is visible in the picture; the time is in EXIF metadata. Reject a broken image or one for a different invoice.

## Q7

Compare both PDFs, not just their filenames. The existing DOCS PDF is a comparison record; check invoice, bay and approval status.

## Q8

File slack is unused space at the end of the last cluster. Use entry_offset from the helper, not the fls file address.

## Q9

The manifest lists decoded_sha256 and decoded_length. Compare them with sha256sum and wc -c before trusting the message.

## Q10

A CSV viewer and calculator are enough. Start at STAGE, end at the final successful SEND, and use the exact ZIP hash.
