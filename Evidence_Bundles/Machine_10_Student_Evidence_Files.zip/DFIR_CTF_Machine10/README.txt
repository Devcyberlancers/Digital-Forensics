Vault Breach v2. Start with START_HERE.md. Previous fake E01 and container artifacts have been removed.
