# Tools - Vault Breach v2

Use Kali or Windows. No programming or new installation is required for the primary route. Extract the complete download before opening evidence.

- Browser/PDF viewer: Ctrl+O opens local HTML reports and PDF evidence. Q2's readable report is generated from valid SQLite, with source hash and UTC times. DB Browser is an optional independent route.
- Plain text editor: read EML headers, JSON manifests and calibration. Open With Mousepad on Kali or an existing editor on Windows.
- Archive Manager: extract protected ZIP, server TAR and recovered TGZ into Working. A TGZ may require opening its inner TAR layer. An archive listing alone does not prove decryption.
- File Inspector: question link opens a local browser helper. Choose a file to calculate its full SHA-256 and byte length. Compare all 64 characters before using shortened submissions.
- Packet Reader: question link opens a local parser for the supplied Ethernet/IPv4/TCP PCAP. It reassembles each supported direction, pairs X-Request-ID records, shows headers/body preview and exports exact HTTP body bytes. Use the search field to narrow records. Hashes are computed from body bytes; it does not choose the relevant record for you. Unsupported captures produce an error, not fabricated records.
- Event Viewer: choose extracted .jsonl audit or receipt files; search identifiers, read complete JSON records and decode a selected Base64 value as text. Decoding does not execute it. Clear the search between different identities.
- Wireshark (optional if present): File > Open PCAP; filter HTTP; Follow TCP Stream to pair requests/responses; File > Export Objects > HTTP for response bodies. Set UTC Date and Time for timeline checks. Use Packet Reader to export request bodies without copying HTTP headers.
- Calculator or paper: apply true UTC = observed - signed offset, using source and validity date. Preserve generation and boot identity with file/PID numbers.

The full WebApp folder includes file-inspector.html, packet-reader.html and event-viewer.html. If you downloaded evidence only, open helpers from the machine web app/full release. Helpers run locally and do not upload evidence. The protected ZIP uses traditional ZipCrypto for compatibility; no VeraCrypt mount is claimed. No real Splunk installation is required or implied.
