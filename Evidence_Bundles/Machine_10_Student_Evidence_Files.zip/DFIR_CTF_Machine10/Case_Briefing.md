# Vault Breach - case VLT-DFIR-2026-1010

On 10 October 2026 a restricted AB47 commercial package was released to procurement. Later, the application server produced a staging archive and an external collector reported an accepted object. A procurement workstation download, a service-account session and server audit trail may be connected, but they do not automatically establish the same human operator.

Investigate the browser download and approved release first. Authenticate the protected archive content, trace the remote session into a staging process, recover the network object and distinguish an accepted transfer from retries and unrelated traffic. Correct source clocks before closing the chronology.

Subject under review: Nisha Rao, procurement account nisha.rao; workstation VB10-WS01. Server APP01 and the service-account session are separate attribution leads. Do not infer intent from account names.

Evidence is structurally valid fictional training material: SQLite browser history, EML, PDF, encrypted ZIP, TAR/JSONL audit records and a real Ethernet/IPv4/TCP PCAP. The ZIP is not VeraCrypt; no E01 image, live Splunk instance or malicious executable is supplied. HTTP visibility is an explicit post-TLS-termination lab export. Clocks and format scope are documented with the artifacts.
