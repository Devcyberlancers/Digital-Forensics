# Vault Breach v2

1. Extract the whole pack into a fresh folder and confirm PACK_VERSION.txt says v2.
2. Open WebApp/index.html from the full student release, or use the machine page in the portal. Evidence-only packs omit the helper HTML pages.
3. Read Case_Briefing.md. All Evidence/... paths start in DFIR_CTF_Machine10, beside this file.
4. Create Working beside Evidence using the file manager. Keep original evidence unchanged.
5. Follow questions.md in order and retain findings in Questions/student_answer_log.md.

Primary route: existing browser, archive manager, PDF/text viewer and included local tools. Wireshark is recommended if already installed; an offline Packet Reader supports this capture without installation. No scripts, SQL or software installs are necessary. Never execute decoded audit commands.
