# Single hints

Q1: History has no filename extension; do not hash history_report.html or the evidence ZIP.

Q2: The earlier cancelled attempt has the same target filename. Read the ticket parameter of the completed row.

Q3: Use the Approved release field; keep the release code separate from the revision number.

Q4: Custom headers may be hidden in a mail app. Use Open With > Text Editor and read above the blank line in the matching message.

Q5: Build the lowercase hyphenated password from release code, numeric ticket suffix and nonce; then reject the superseded PDF.

Q6: Use plain-text String search rather than entering POST /api/login as a display filter. Follow the candidate TCP stream; a 200 response must belong to svc_portal, not another account.

Q7: Match session, job, parent PID and boot together. A reused PID from another boot is a different process.

Q8: Use the matching job and cookie, not filename alone. The HTTP export dialog's Text Filter only narrows its object list; TCP Stream Save As may include headers.

Q9: Export and hash POST request bodies, then pair each with its response. A 201 for another hash and a 409 for the right hash do not establish a new acceptance.

Q10: Use observed minus signed offset for each source. Read-close is not staging completion, and a reused pathname/inode with another generation is another object.
