# Machine 10 Vault Breach student answer log

Student name: ____________________  Date: ____________________

Use questions.md for the investigation prompts. Record your own answer and the evidence supporting it. Keep original Evidence files unchanged and save recoveries under Working.

| Question | Difficulty | Points | Recorded |
|---|---|---:|---|
| Q1 Verify the acquired browser database | Easy | 5 | [ ] |
| Q2 Recover the completed download ticket | Easy | 5 | [ ] |
| Q3 Read the approved release code | Easy | 5 | [ ] |
| Q4 Match the current mail handoff | Easy | 5 | [ ] |
| Q5 Unlock and authenticate commercial terms | Medium | 8 | [ ] |
| Q6 Trace the successful attack session | Medium | 8 | [ ] |
| Q7 Reconstruct the staging command | Medium | 8 | [ ] |
| Q8 Recover the staged network object | Medium | 8 | [ ] |
| Q9 Prove which external transfer was accepted | Hard | 10 | [ ] |
| Q10 Close the corrected staging-to-acceptance timeline | Hard | 10 | [ ] |

## Findings

### Q1 Verify the acquired browser database

**Tool to be used:** Included File Inspector or existing SHA-256 utility

**Answer format:** `<first16_sha256>`

**My answer:** ____________________

**Source file(s) and record / request / stream identifier(s):**

- ____________________

**Tool actions, filters or search method:**

- ____________________

**Observation and reasoning:**

- ____________________

**Full hash comparison or time calculation, where relevant:**

- ____________________

**Screenshot or saved output reference:** ____________________

### Q2 Recover the completed download ticket

**Tool to be used:** Firefox acquisition report; DB Browser optional

**Answer format:** `<ticket_id>`

**My answer:** ____________________

**Source file(s) and record / request / stream identifier(s):**

- ____________________

**Tool actions, filters or search method:**

- ____________________

**Observation and reasoning:**

- ____________________

**Full hash comparison or time calculation, where relevant:**

- ____________________

**Screenshot or saved output reference:** ____________________

### Q3 Read the approved release code

**Tool to be used:** Browser PDF viewer

**Answer format:** `<release_code>`

**My answer:** ____________________

**Source file(s) and record / request / stream identifier(s):**

- ____________________

**Tool actions, filters or search method:**

- ____________________

**Observation and reasoning:**

- ____________________

**Full hash comparison or time calculation, where relevant:**

- ____________________

**Screenshot or saved output reference:** ____________________

### Q4 Match the current mail handoff

**Tool to be used:** Existing plain text editor or mail viewer

**Answer format:** `<four_digits>`

**My answer:** ____________________

**Source file(s) and record / request / stream identifier(s):**

- ____________________

**Tool actions, filters or search method:**

- ____________________

**Observation and reasoning:**

- ____________________

**Full hash comparison or time calculation, where relevant:**

- ____________________

**Screenshot or saved output reference:** ____________________

### Q5 Unlock and authenticate commercial terms

**Tool to be used:** Archive Manager; File Inspector; browser PDF viewer

**Answer format:** `FLAG{vault_<project_code>_<ceiling_inr>}`

**My answer:** ____________________

**Source file(s) and record / request / stream identifier(s):**

- ____________________

**Tool actions, filters or search method:**

- ____________________

**Observation and reasoning:**

- ____________________

**Full hash comparison or time calculation, where relevant:**

- ____________________

**Screenshot or saved output reference:** ____________________

### Q6 Trace the successful attack session

**Tool to be used:** Wireshark or included Packet Reader

**Answer format:** `<session_value>`

**My answer:** ____________________

**Source file(s) and record / request / stream identifier(s):**

- ____________________

**Tool actions, filters or search method:**

- ____________________

**Observation and reasoning:**

- ____________________

**Full hash comparison or time calculation, where relevant:**

- ____________________

**Screenshot or saved output reference:** ____________________

### Q7 Reconstruct the staging command

**Tool to be used:** Archive Manager; included Event Viewer and Base64 decoder

**Answer format:** `<archive_basename>`

**My answer:** ____________________

**Source file(s) and record / request / stream identifier(s):**

- ____________________

**Tool actions, filters or search method:**

- ____________________

**Observation and reasoning:**

- ____________________

**Full hash comparison or time calculation, where relevant:**

- ____________________

**Screenshot or saved output reference:** ____________________

### Q8 Recover the staged network object

**Tool to be used:** Wireshark/Packet Reader; Archive Manager; File Inspector

**Answer format:** `<first16_tgz_sha256>`

**My answer:** ____________________

**Source file(s) and record / request / stream identifier(s):**

- ____________________

**Tool actions, filters or search method:**

- ____________________

**Observation and reasoning:**

- ____________________

**Full hash comparison or time calculation, where relevant:**

- ____________________

**Screenshot or saved output reference:** ____________________

### Q9 Prove which external transfer was accepted

**Tool to be used:** Packet Reader or Wireshark; File Inspector; Event Viewer

**Answer format:** `FLAG{exfil_<object_id>_<destination_ip>}`

**My answer:** ____________________

**Source file(s) and record / request / stream identifier(s):**

- ____________________

**Tool actions, filters or search method:**

- ____________________

**Observation and reasoning:**

- ____________________

**Full hash comparison or time calculation, where relevant:**

- ____________________

**Screenshot or saved output reference:** ____________________

### Q10 Close the corrected staging-to-acceptance timeline

**Tool to be used:** Event Viewer; existing calculator; Packet Reader

**Answer format:** `FLAG{closure_<job_id>_<generation>_<gap_seconds>}`

**My answer:** ____________________

**Source file(s) and record / request / stream identifier(s):**

- ____________________

**Tool actions, filters or search method:**

- ____________________

**Observation and reasoning:**

- ____________________

**Full hash comparison or time calculation, where relevant:**

- ____________________

**Screenshot or saved output reference:** ____________________

## Case conclusion

Supported findings: ____________________

Limits on attribution or intent: ____________________
