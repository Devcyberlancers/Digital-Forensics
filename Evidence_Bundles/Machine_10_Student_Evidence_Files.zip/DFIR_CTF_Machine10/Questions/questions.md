# Machine 10 Vault Breach questions

Current pack: v2. 4 easy / 4 medium / 2 hard. Maximum score: 72 points. Design difficulty: 4.5/5.

All Evidence/... paths start inside DFIR_CTF_Machine10. Open the supplied local helpers from the full web app. Each question below has one hint and its submission format.

## Q1 Verify the acquired browser database (Easy, 5 points)

Hash Evidence/Browser/History and compare its complete SHA-256 with Hashes/SHA256SUMS.txt.
After the full values match, submit the first 16 hexadecimal characters.

**Tool to be used:** Included File Inspector or existing SHA-256 utility

**Answer format:** `<first16_sha256>`

**Hint:** History has no filename extension; do not hash history_report.html or the evidence ZIP.

## Q2 Recover the completed download ticket (Easy, 5 points)

Open Evidence/Browser/history_report.html, exported from the acquired History database.
For release_bundle.zip, identify the COMPLETE download on 10 October and read its tab_url.
What release ticket was used for that completed attempt?

**Tool to be used:** Firefox acquisition report; DB Browser optional

**Answer format:** `<ticket_id>`

**Hint:** The earlier cancelled attempt has the same target filename. Read the ticket parameter of the completed row.

## Q3 Read the approved release code (Easy, 5 points)

Open Evidence/Documents/release_board.pdf and review the decision for 10 October.
What release code belongs to the approved revision, rather than the superseded one?

**Tool to be used:** Browser PDF viewer

**Answer format:** `<release_code>`

**Hint:** Use the Approved release field; keep the release code separate from the revision number.

## Q4 Match the current mail handoff (Easy, 5 points)

Open the .eml files in Evidence/Mail with a plain text editor so all headers are visible.
Select the message matching both the Q2 ticket and Q3 release code.
What is its X-Release-Nonce header value?

**Tool to be used:** Existing plain text editor or mail viewer

**Answer format:** `<four_digits>`

**Hint:** Custom headers may be hidden in a mail app. Use Open With > Text Editor and read above the blank line in the matching message.

## Q5 Unlock and authenticate commercial terms (Medium, 8 points)

Use the current handoff recipe and Q2-Q4 facts to extract Evidence/Vault/release_bundle.zip into Working.
Read release_manifest.json and authenticate its APPROVED PDF using the complete SHA-256.
Submit that PDF’s project code and contract ceiling in INR, without commas.

**Tool to be used:** Archive Manager; File Inspector; browser PDF viewer

**Answer format:** `FLAG{vault_<project_code>_<ceiling_inr>}`

**Hint:** Build the lowercase hyphenated password from release code, numeric ticket suffix and nonce; then reject the superseded PDF.

## Q6 Trace the successful attack session (Medium, 8 points)

Open Evidence/Network/edge_capture.pcap and locate /api/login exchanges.
In Wireshark use Find Packet > Packet list > String, or search the path in Packet Reader.
Compare the paired responses to find repeated rejected svc_portal logins followed by authentication.
Submit the session value issued in that successful response's Set-Cookie header.

**Tool to be used:** Wireshark or included Packet Reader

**Answer format:** `<session_value>`

**Hint:** Use plain-text String search rather than entering POST /api/login as a display filter. Follow the candidate TCP stream; a 200 response must belong to svc_portal, not another account.

## Q7 Reconstruct the staging command (Medium, 8 points)

Extract Evidence/Server/app01_triage.tar into Working and inspect var/log/portal/audit.jsonl.
Trace the Q6 session through REQUEST_ACCEPTED to its PROCESS_START on boot BOOT-1010-A.
Decode that event’s command_b64 as text and submit the output archive basename; never execute the command.

**Tool to be used:** Archive Manager; included Event Viewer and Base64 decoder

**Answer format:** `<archive_basename>`

**Hint:** Match session, job, parent PID and boot together. A reused PID from another boot is a different process.

## Q8 Recover the staged network object (Medium, 8 points)

Recover the successful PCAP download for the Q7 job carried by the Q6 session.
Save its HTTP response body with Export Objects > HTTP or Packet Reader's Save body.
Extract the TGZ and compare its PDF's full SHA-256 with the APPROVED entry from Q5.
Submit the first 16 SHA-256 characters of the original saved TGZ, not the PDF.

**Tool to be used:** Wireshark/Packet Reader; Archive Manager; File Inspector

**Answer format:** `<first16_tgz_sha256>`

**Hint:** Use the matching job and cookie, not filename alone. The HTTP export dialog's Text Filter only narrows its object list; TCP Stream Save As may include headers.

## Q9 Prove which external transfer was accepted (Hard, 10 points)

Find the external /ingest POST whose complete body matches the Q8 .tgz SHA-256.
Corroborate its request_id and accepted response with Evidence/Server/egress_receipts.jsonl.
Exclude the incomplete failure, duplicate retry and other-content success; submit the accepted object ID and destination IP.

**Tool to be used:** Packet Reader or Wireshark; File Inspector; Event Viewer

**Answer format:** `FLAG{exfil_<object_id>_<destination_ip>}`

**Hint:** Export and hash POST request bodies, then pair each with its response. A 201 for another hash and a 409 for the right hash do not establish a new acceptance.

## Q10 Close the corrected staging-to-acceptance timeline (Hard, 10 points)

Match the Q8 archive hash to the completed FILE_CLOSE_WRITE for the Q7 job and retain its file generation.
Correct that APP01 time and the Q9 accepted EDGE01 receipt using Evidence/Clock/calibration.json for 10 October.
Measure accepted UTC minus completed-staging UTC; corroborate acceptance with capture UTC.
Submit the job ID, original generation and positive gap in seconds.

**Tool to be used:** Event Viewer; existing calculator; Packet Reader

**Answer format:** `FLAG{closure_<job_id>_<generation>_<gap_seconds>}`

**Hint:** Use observed minus signed offset for each source. Read-close is not staging completion, and a reused pathname/inode with another generation is another object.
