Memory Mirage v5: read START_HERE.md. Extract the full student release before opening WebApp/index.html. Evidence paths are relative to Student_VM/DFIR_CTF_Machine07. Linux paths are case-sensitive.

Current terminal recipes: Tools_Guide/Terminal_Workflows.md (from the evidence root). Q10 combines Q4 child PID, Q5 session and Q6 sent-byte total with independent thread/timeline analysis.
