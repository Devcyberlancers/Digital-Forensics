# One hint per question

## Q1

Hash the file bytes, not copied text; the complete digest has 64 hexadecimal characters.

## Q2

Count matching log lines, not words in their descriptions.

## Q3

Read the left-hand hexadecimal bytes, not the printable-text column.

## Q4

Indentation shows parent-child relationships; the other running instance belongs to a different branch.

## Q5

Restore the fragment order before decoding; the entry point ends at the space before --session.

## Q6

Exclude RECV rows, the launcher’s traffic and the child’s other remote address; add the remaining SEND byte counts.

## Q7

Match both PID and VAD start; exclude the JIT region and file-backed system DLLs.

## Q8

Choose the matching .bin file in the offline decoder; it prints decoded JSON without executing the sample.

## Q9

A successful GET, a failed POST and another process’s request are decoys; check both successive gaps, not just one.

## Q10

Use Q4/Q5/Q6 directly; Q3 is a file signature, not a launcher identity. The thread address must fall inside the Q7 VAD, and elapsed time starts at launcher creation.
