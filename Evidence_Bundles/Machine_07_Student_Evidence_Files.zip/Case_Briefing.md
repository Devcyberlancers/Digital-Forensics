# Memory Mirage v5

A guided, offline investigation of synthetic memory-analysis exports. Ten questions, six derived flags, 72 points; allow 75–105 minutes. No real RAM image is included.

Host ORION-WS-077 was triaged after unusual application activity. Begin with basic acquisition details, identify a launcher and child, then follow the loaded module, socket, memory region and decoded callback configuration. The final questions correlate sources. Work on copies and never execute dump bytes.

Answers ignore capitalization AND all whitespace (spaces, tabs and line breaks), including inside flags. Punctuation and token order still matter. Each question has one hint and one answer format. Q1–Q4 each request one value; Q5–Q10 use the displayed FLAG{...} wrapper. Evidence timestamps are UTC.

Current terminal recipes: Tools_Guide/Terminal_Workflows.md (from the evidence root). Q10 combines Q4 child PID, Q5 session and Q6 sent-byte total with independent thread/timeline analysis.
