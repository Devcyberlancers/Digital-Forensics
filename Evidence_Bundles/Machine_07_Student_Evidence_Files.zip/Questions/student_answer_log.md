# Answer log

## Q1 — Hash the acquisition record

Format: `<first_16_sha256_characters>`

Answer:
Evidence path / command / observation:

## Q2 — Count collection warnings

Format: `<whole_number>`

Answer:
Evidence path / command / observation:

## Q3 — Read the binary signature

Format: `<four_hex_characters>`

Answer:
Evidence path / command / observation:

## Q4 — Follow the surviving branch

Format: `<decimal_pid>`

Answer:
Evidence path / command / observation:

## Q5 — Reassemble the loader command

Format: `FLAG{loader_<entrypoint>_<session_token>}`

Answer:
Evidence path / command / observation:

## Q6 — Calculate outbound socket traffic

Format: `FLAG{socket_<ip_with_underscores>_<port>_<total_sent_bytes>}`

Answer:
Evidence path / command / observation:

## Q7 — Locate the suspicious memory region

Format: `FLAG{vad_<0x_start_address>}`

Answer:
Evidence path / command / observation:

## Q8 — Decode the selected region

Format: `FLAG{campaign_<campaign_with_underscores>}`

Answer:
Evidence path / command / observation:

## Q9 — Prove the beacon pattern

Format: `FLAG{beacon_<hostname>_<interval_seconds>_<successful_count>}`

Answer:
Evidence path / command / observation:

## Q10 — Close the process-to-network chain

Format: `FLAG{closure_<childpid>_<session_token>_<sent_bytes>_<thread_hhmmss>_<elapsed_seconds>}`

Answer:
Evidence path / command / observation:
