# Memory Mirage v5

Synthetic memory-export investigation · 10 questions · 6 flags · 72 points · 75–105 minutes

Answers ignore capitalization AND all whitespace (spaces, tabs and line breaks), including inside flags. Punctuation and token order still matter. Each question has one hint and one answer format. Q1–Q4 each request one value; Q5–Q10 use the displayed FLAG{...} wrapper. Evidence timestamps are UTC.

All evidence paths start inside Student_VM/DFIR_CTF_Machine07. See Tools_Guide/Terminal_Workflows.md for optional/required terminal recipes.

### Q1 — Hash the acquisition record (easy; 5 points)

Calculate the SHA-256 of Evidence/Acquisition/acquisition.json. Submit only the first 16 hexadecimal characters. See Terminal_Workflows.md, Q1, for the command.

**Answer format:** `<first_16_sha256_characters>`

**Hint:** Hash the file bytes, not copied text; the complete digest has 64 hexadecimal characters.

### Q2 — Count collection warnings (easy; 5 points)

Open Evidence/Triage/collection.log. How many lines have severity WARN? Count WARN entries only.

**Answer format:** `<whole_number>`

**Hint:** Count matching log lines, not words in their descriptions.

### Q3 — Read the binary signature (easy; 5 points)

Inspect the first two bytes of Evidence/Recovered/module_header.bin in a hex viewer or terminal. Submit those bytes as four hexadecimal characters without spaces. See Terminal_Workflows.md, Q3.

**Answer format:** `<four_hex_characters>`

**Hint:** Read the left-hand hexadecimal bytes, not the printable-text column.

### Q4 — Follow the surviving branch (easy; 5 points)

Open Evidence/ProcessTree/process_tree.txt. Which RUNNING process is directly underneath the exited Downloads launcher? Submit its PID only. Use this child PID for later questions.

**Answer format:** `<decimal_pid>`

**Hint:** Indentation shows parent-child relationships; the other running instance belongs to a different branch.

### Q5 — Reassemble the loader command (medium; 8 points)

Evidence/Loader/command_fragments.csv contains shuffled Base64 pieces. Sort numerically by part, join data_b64 WITHOUT separators, and decode once. Terminal_Workflows.md, Q5, gives Windows and Kali commands. Confirm the decoded command matches the Q4 child in windows_cmdline.csv. Submit its module entry point (after !) and --session token, lowercased, in the flag.

**Answer format:** `FLAG{loader_<entrypoint>_<session_token>}`

**Hint:** Restore the fragment order before decoding; the entry point ends at the space before --session.

### Q6 — Calculate outbound socket traffic (medium; 8 points)

Identify the Q4 child’s ESTABLISHED remote endpoint in Evidence/Volatility/windows_netscan.csv. In Evidence/Network/socket_events.csv, sum bytes only for SEND rows matching that PID, remote IP and remote port. Use Terminal_Workflows.md, Q6, to filter and total the rows. Include the endpoint and total bytes; replace IP dots with underscores.

**Answer format:** `FLAG{socket_<ip_with_underscores>_<port>_<total_sent_bytes>}`

**Hint:** Exclude RECV rows, the launcher’s traffic and the child’s other remote address; add the remaining SEND byte counts.

### Q7 — Locate the suspicious memory region (medium; 8 points)

For the Q4 child PID, compare Evidence/Volatility/windows_malfind.csv and windows_vadinfo.csv. Which candidate VAD is private_memory=1, has no mapped file (-), and begins with MZ bytes (4D 5A)? Submit its start address, retaining 0x and all leading zeroes. These clues identify the candidate for this exercise; RWX alone does not prove injection.

**Answer format:** `FLAG{vad_<0x_start_address>}`

**Hint:** Match both PID and VAD start; exclude the JIT region and file-backed system DLLs.

### Q8 — Decode the selected region (medium; 8 points)

Use Evidence/Dumps/dump_index.csv to select the dump matching the PID from Q4 and address from Q7. Open Tools_Guide/decode_config.html in your browser and select that dump. What campaign is recorded? Replace the campaign hyphen with an underscore in the flag.

**Answer format:** `FLAG{campaign_<campaign_with_underscores>}`

**Hint:** Choose the matching .bin file in the offline decoder; it prints decoded JSON without executing the sample.

### Q9 — Prove the beacon pattern (hard; 10 points)

Use Q8’s decoded server, port, uri and sleep_seconds, plus Q6’s endpoint and Q4’s child PID. In Evidence/Network/http_requests.csv, keep only that PID, hostname, resolved IP, port and URI with method POST and status 200; corroborate resolution in dns_cache.csv. Sort by time_utc and calculate BOTH gaps between the three matching requests. Only if both gaps equal the decoded sleep_seconds, submit hostname, verified interval and successful request count. Terminal_Workflows.md, Q9, provides a filtering/timing recipe.

**Answer format:** `FLAG{beacon_<hostname>_<interval_seconds>_<successful_count>}`

**Hint:** A successful GET, a failed POST and another process’s request are decoys; check both successive gaps, not just one.

### Q10 — Close the process-to-network chain (hard; 10 points)

Build one closure flag using the child PID from Q4 (easy), session token from Q5 and sent-byte total from Q6 (medium). For your own timeline analysis, use Q7’s VAD bounds in windows_vadinfo.csv to select the child THREAD_START inside that region in Timeline/telemetry.csv; ignore the thread outside it. Then use the child’s PPID in windows_psscan.csv to locate its launcher PROCESS_CREATE in telemetry, and subtract that time from the first child CONNECT time, corroborated by netscan. Include the selected thread time as HHMMSS UTC and the whole-second interval. Terminal_Workflows.md, Q10, explains range/time calculations.

**Answer format:** `FLAG{closure_<childpid>_<session_token>_<sent_bytes>_<thread_hhmmss>_<elapsed_seconds>}`

**Hint:** Use Q4/Q5/Q6 directly; Q3 is a file signature, not a launcher identity. The thread address must fall inside the Q7 VAD, and elapsed time starts at launcher creation.
