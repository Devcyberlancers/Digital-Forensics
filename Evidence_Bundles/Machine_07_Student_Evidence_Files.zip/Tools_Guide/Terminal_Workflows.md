# Terminal workflows — Windows and Kali

Run commands from Student_VM/DFIR_CTF_Machine07 (or the root of the extracted evidence-only ZIP). Paths are case-sensitive on Kali. Windows paths inside CSV cells describe evidence, not your computer. No sample or decoded command should be executed. These commands only read, decode and calculate.

## Q1 — calculate a hash

Kali:

~~~bash
sha256sum Evidence/Acquisition/acquisition.json
~~~

PowerShell:

~~~powershell
Get-FileHash -Algorithm SHA256 Evidence/Acquisition/acquisition.json
~~~

Submit the first 16 hexadecimal characters, not the full digest and not a filename. Hash original bytes; opening and re-saving the JSON can change its hash.

## Q2 — count warnings (terminal optional)

~~~bash
grep -c ' WARN ' Evidence/Triage/collection.log
~~~

~~~powershell
(Select-String -Path Evidence/Triage/collection.log -Pattern ' WARN ').Count
~~~

## Q3 — inspect bytes

~~~bash
xxd -l 2 Evidence/Recovered/module_header.bin
~~~

~~~powershell
Format-Hex -Path Evidence/Recovered/module_header.bin
~~~

Take the first two hex bytes from the data column. Ignore the address/offset and printable text. Q4 is a separate tree-reading task in Evidence/ProcessTree/.

## Q5 — reconstruct and decode, without executing

Kali:

~~~bash
mkdir -p Working
tail -n +2 Evidence/Loader/command_fragments.csv | sort -t, -k1,1n | cut -d, -f2 | tr -d '\r\n' | base64 --decode | tee Working/decoded_command.txt
printf '\n'
~~~

PowerShell:

~~~powershell
New-Item -ItemType Directory -Path Working -Force | Out-Null
$parts = Import-Csv Evidence/Loader/command_fragments.csv | Sort-Object { [int]$_.part }
$joined = $parts.data_b64 -join ''
$decoded = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($joined))
$decoded
$decoded | Set-Content Working/decoded_command.txt
~~~

Read the entry point after ! and the value after --session. Verify this command against the row for your Q4 child in windows_cmdline.csv. Do not paste the decoded command into a shell as an executable command.

## Q6 — filter a socket and sum SEND bytes

Enter your Q4 PID when prompted. These commands discover its ESTABLISHED endpoint and use every endpoint field in the sum.

Kali:

~~~bash
read -r -p 'Child PID from Q4: ' child_pid
endpoint=$(awk -F, -v p="$child_pid" 'NR>1 && $1==p && $6=="ESTABLISHED" {print $4 "," $5}' Evidence/Volatility/windows_netscan.csv)
IFS=, read -r remote_ip remote_port <<< "$endpoint"
printf 'Selected remote endpoint: %s:%s\n' "$remote_ip" "$remote_port"
awk -F, -v p="$child_pid" -v ip="$remote_ip" -v port="$remote_port" 'NR>1 && $1==p && $2==ip && $3==port && $4=="SEND" {print; total+=$5} END {print "SEND total:",total+0}' Evidence/Network/socket_events.csv
~~~

PowerShell:

~~~powershell
$childPid = Read-Host 'Child PID from Q4'
$remote = Import-Csv Evidence/Volatility/windows_netscan.csv | Where-Object { $_.pid -eq $childPid -and $_.state -eq 'ESTABLISHED' }
$remote | Format-Table pid,remote_ip,remote_port,state
$sendRows = Import-Csv Evidence/Network/socket_events.csv | Where-Object { $_.pid -eq $childPid -and $_.remote_ip -eq $remote.remote_ip -and $_.remote_port -eq $remote.remote_port -and $_.direction -eq 'SEND' }
$sendRows | Format-Table
($sendRows | Measure-Object -Property bytes -Sum).Sum
~~~

If no endpoint appears, check the PID. There is one established endpoint for the intended child. Preserve the endpoint and byte total for Q9/Q10. Q7 and Q8 retain the VAD comparison and offline configuration decoder described in their questions.

## Q9 — filter successful callbacks and measure every gap

Use the Q8 decoder for server, port, uri and sleep_seconds. Confirm server → address in Evidence/Volatility/dns_cache.csv before using the Q6 endpoint. Re-run Q6 if your terminal session was closed; its variables are used below.

Kali:

~~~bash
read -r -p 'Server hostname from decoded config: ' server
read -r -p 'URI from decoded config (include /): ' uri
mkdir -p Working
awk -F, -v p="$child_pid" -v h="$server" -v ip="$remote_ip" -v port="$remote_port" -v u="$uri" 'NR>1 && $2==p && $3==h && $4==ip && $5==port && $6=="POST" && $7==u && $8==200 {print $1}' Evidence/Network/http_requests.csv | sort > Working/beacon_times.txt
cat Working/beacon_times.txt
wc -l < Working/beacon_times.txt
previous=''
while IFS= read -r stamp; do
  current=$(date -u -d "$stamp" +%s)
  if [ -n "$previous" ]; then printf 'gap_seconds=%s\n' "$((current-previous))"; fi
  previous=$current
done < Working/beacon_times.txt
~~~

PowerShell:

~~~powershell
$server = Read-Host 'Server hostname from decoded config'
$uri = Read-Host 'URI from decoded config (include /)'
$callbacks = @(Import-Csv Evidence/Network/http_requests.csv | Where-Object { $_.pid -eq $childPid -and $_.host -eq $server -and $_.remote_ip -eq $remote.remote_ip -and $_.port -eq $remote.remote_port -and $_.method -eq 'POST' -and $_.uri -eq $uri -and $_.status -eq '200' } | Sort-Object time_utc)
$callbacks | Format-Table
$callbacks.Count
for ($index=1; $index -lt $callbacks.Count; $index++) {
  $before = [datetime]::ParseExact($callbacks[$index-1].time_utc,'yyyy-MM-dd HH:mm:ss',[cultureinfo]::InvariantCulture)
  $after = [datetime]::ParseExact($callbacks[$index].time_utc,'yyyy-MM-dd HH:mm:ss',[cultureinfo]::InvariantCulture)
  ($after-$before).TotalSeconds
}
~~~

All timestamps represent UTC; no local-time conversion is required. Check both gaps against sleep_seconds, not only the first. Require the decoded port to equal the selected socket port too. If filtering returns no rows, recheck spelling, PID and the URI's leading slash. The flag uses hostname, interval and successful count; it is not a copy of a row.

## Q10 — connect earlier findings to your own timeline analysis

Carry forward Q4 child PID, Q5 session token, Q6 SEND total and Q7 VAD start. Obtain the VAD end from the same vadinfo row. In telemetry, only one child THREAD_START address falls within that inclusive region. The other starts in a mapped DLL and must be excluded. Confirm the selected row's address numerically if needed.

Kali range arithmetic (enter addresses found in evidence):

~~~bash
read -r -p 'VAD start (0x...): ' vad_start
read -r -p 'VAD end (0x...): ' vad_end
read -r -p 'Candidate thread start (0x...): ' thread_address
if (( thread_address >= vad_start && thread_address <= vad_end )); then echo 'inside'; else echo 'outside'; fi
~~~

PowerShell equivalent:

~~~powershell
$vadStart = [Convert]::ToInt64((Read-Host 'VAD start without 0x'),16)
$vadEnd = [Convert]::ToInt64((Read-Host 'VAD end without 0x'),16)
$threadAddress = [Convert]::ToInt64((Read-Host 'Candidate thread start without 0x'),16)
($threadAddress -ge $vadStart -and $threadAddress -le $vadEnd)
~~~

Use the selected THREAD_START time for the flag's HHMMSS component. For elapsed seconds, use child PPID from psscan to find the launcher PROCESS_CREATE, then locate the first child CONNECT. Cross-check CONNECT against netscan. Do not use Q3: that question identifies binary signature bytes, not a process.

Kali time subtraction:

~~~bash
read -r -p 'Launcher creation UTC (YYYY-MM-DD HH:MM:SS): ' launch_time
read -r -p 'First child CONNECT UTC (YYYY-MM-DD HH:MM:SS): ' connect_time
echo "$(( $(date -u -d "$connect_time" +%s) - $(date -u -d "$launch_time" +%s) ))"
~~~

PowerShell time subtraction:

~~~powershell
$launchTime = [datetime]::ParseExact((Read-Host 'Launcher creation UTC'),'yyyy-MM-dd HH:mm:ss',[cultureinfo]::InvariantCulture)
$connectTime = [datetime]::ParseExact((Read-Host 'First child CONNECT UTC'),'yyyy-MM-dd HH:mm:ss',[cultureinfo]::InvariantCulture)
($connectTime-$launchTime).TotalSeconds
~~~

Assemble the exact component order shown in the question. Capitalization and whitespace anywhere are ignored, but punctuation and token order are still checked.
