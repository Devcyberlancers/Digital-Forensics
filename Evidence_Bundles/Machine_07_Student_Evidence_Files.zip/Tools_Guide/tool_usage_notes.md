# Memory Mirage v5

A guided, offline investigation of synthetic memory-analysis exports. Ten questions, six derived flags, 72 points; allow 75–105 minutes. No real RAM image is included.

Read ../START_HERE.md for identical Windows/Kali folder layout and commands.

## Concepts

PID is a process identifier; PPID is its parent. pslist lists active processes; psscan can also retain exited ones. A missing pslist entry alone does not prove hiding. cmdline records execution arguments; ! separates the module path and entry point in these normalized exports. netscan attributes sockets to PIDs. VAD records describe memory regions; malfind candidates require corroboration because JIT memory can be executable too. MZ bytes alone are not proof of malware. All samples and exports are synthetic.

## Decode helper

Select the correct dump_index.csv row by PID AND VAD start. Open Tools_Guide/decode_config.html in a browser and select the matching .bin file. It needs no server, network or Python installation. The output is decoded JSON, not an answer flag. The helper only reads bytes. The Python helper is an optional alternative.

Current terminal recipes: Tools_Guide/Terminal_Workflows.md (from the evidence root). Q10 combines Q4 child PID, Q5 session and Q6 sent-byte total with independent thread/timeline analysis.
