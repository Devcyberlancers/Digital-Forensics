#!/usr/bin/env python3
"""Print CONFIG_B64 JSON from a teaching dump without executing its bytes."""
import argparse
import base64
import json
from pathlib import Path

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('dump', type=Path, help='Path to the selected .bin sample')
    args = parser.parse_args()
    try:
        data = args.dump.read_bytes()
        marker = b'CONFIG_B64='
        if marker not in data:
            parser.error('No CONFIG_B64 marker in this file. Check PID and VAD base in dump_index.csv.')
        value = data.split(marker, 1)[1].split(b'\x00', 1)[0]
        config = json.loads(base64.b64decode(value, validate=True).decode('utf-8'))
        print(json.dumps(config, indent=2))
    except (OSError, ValueError, UnicodeError) as exc:
        parser.error(str(exc))

if __name__ == '__main__':
    main()
