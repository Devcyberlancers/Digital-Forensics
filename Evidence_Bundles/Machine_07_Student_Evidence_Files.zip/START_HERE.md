# Memory Mirage v5

A guided, offline investigation of synthetic memory-analysis exports. Ten questions, six derived flags, 72 points; allow 75–105 minutes. No real RAM image is included.

## Start on Windows or Kali Linux

1. Extract the **entire** Machine_07_Memory_Mirage_Student.zip. Do not open the web app from inside an archive viewer.
2. Open WebApp/index.html in a current browser. The Questions tab links to the evidence ZIP; the same evidence is already extracted under Student_VM/DFIR_CTF_Machine07/.
3. For every evidence path in a question, begin inside Student_VM/DFIR_CTF_Machine07. Capitalization matters on Linux: Evidence and evidence are different names.

```text
Machine_07_Memory_Mirage_Student/
  WebApp/index.html
  Student_Evidence_Files.zip
  START_HERE.md
  Student_VM/DFIR_CTF_Machine07/
    START_HERE.md
    Evidence/
      Acquisition/acquisition.json
      Volatility/        (process, command-line, socket and VAD CSVs)
      Dumps/             (dump index and teaching byte samples)
      Timeline/telemetry.csv
    Hashes/SHA256SUMS.txt
    Questions/questions.md
    Hints/hints.md
    Tools_Guide/decode_config.html
```

If using only Student_Evidence_Files.zip, extract it into a new folder. Its root directly contains Evidence/, Hashes/, Questions/ and Tools_Guide/. It does not contain WebApp/.

## Kali terminal

From the extracted student package folder:

```bash
cd Student_VM/DFIR_CTF_Machine07
ls Evidence
cat Evidence/Acquisition/acquisition.json
# Integrity check; Q1 asks only the first 16 characters for acquisition.json:
sha256sum -c Hashes/SHA256SUMS.txt
# For Q8, replace DUMP_FILENAME.bin using the matching dump_index.csv row:
python3 Tools_Guide/decode_config.py Evidence/Dumps/DUMP_FILENAME.bin
```

## Windows PowerShell

From the extracted student package folder:

```powershell
Set-Location Student_VM/DFIR_CTF_Machine07
Get-ChildItem Evidence
Get-Content Evidence/Acquisition/acquisition.json
# For Q8, use your installed Python 3 launcher and the selected filename:
py -3 Tools_Guide/decode_config.py Evidence/Dumps/DUMP_FILENAME.bin
```

For Q8, the simplest route on BOTH systems is to open Tools_Guide/decode_config.html in a browser and choose your selected .bin file. It works offline and needs no Python installation. The terminal Python commands above are optional alternatives only. Read CSVs in a text editor or spreadsheet viewer; no PowerShell-specific command is needed to solve them.

Paths like C:\Users\nisha inside CSV cells describe the investigated Windows host. They are evidence values, not folders you must find on Kali. Use the actual package paths above.

Answers ignore capitalization AND all whitespace (spaces, tabs and line breaks), including inside flags. Punctuation and token order still matter. Each question has one hint and one answer format. Q1–Q4 each request one value; Q5–Q10 use the displayed FLAG{...} wrapper. Evidence timestamps are UTC.

Current terminal recipes: Tools_Guide/Terminal_Workflows.md (from the evidence root). Q10 combines Q4 child PID, Q5 session and Q6 sent-byte total with independent thread/timeline analysis.
