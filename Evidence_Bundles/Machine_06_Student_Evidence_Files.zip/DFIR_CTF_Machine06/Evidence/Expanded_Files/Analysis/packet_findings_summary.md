# Packet Findings Worksheet

This worksheet contains no submit-ready answers.

## Aurora
Record the first HTTP client/server pair and path. Inspect the redirect, then compare later TCP traffic between the same hosts with HTTP.

## Blaster
Filter TCP 4444 and use Follow TCP Stream. Record the command and executable named in it.

## DoS
Use SYN-without-ACK filtering. Record the repeated destination and missing completion behavior.

## EvilProgram
Use endpoints, conversations, DNS, and HTTP. Record repeated host, domain, method, URI, and executable filename.
