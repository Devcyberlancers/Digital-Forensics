# Wireshark Filter Guide

This guide gives investigation patterns. Replace placeholders only after identifying candidates from the packet list, Endpoints, or Conversations.

## General

- Packet count: frame
- HTTP only: http
- DNS only: dns
- TCP stream: right-click a selected packet, then choose Follow > TCP Stream
- Conversations: Statistics > Conversations
- Endpoints: Statistics > Endpoints

## Aurora investigation patterns

    http
    http.response.code >= 300 && http.response.code < 400
    ip.addr == <candidate_internal_host>
    tcp.port == <service_discovered_in_conversations>

Use HTTP first to identify the host pair and request/response relationship. Then use Conversations to discover any second TCP service between that same host pair.

## Blaster investigation patterns

    tcp
    tcp.port == <service_discovered_in_conversations>

Start in Statistics > Conversations. Select the relevant conversation before using Follow TCP Stream. A port alone is not proof of malicious activity.

## DoS investigation patterns

    tcp.flags.syn == 1 && tcp.flags.ack == 0
    tcp.len == 0

Use the first filter to test a SYN-only hypothesis. Count the resulting packets and compare their destination and completion behaviour.

## EvilProgram investigation patterns

    dns
    ip.addr == <candidate_host>
    http
    http.request.uri contains ".exe"
    dns.qry.name contains <suspicious_keyword>

Begin with DNS to identify a candidate host and domain. Then correlate that candidate host with HTTP activity, looking for an executable download.
