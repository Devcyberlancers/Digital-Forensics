# Wireshark Investigation Checklist

## Read before filtering

- Source and destination show direction. A high temporary port usually identifies the client side; a stable lower port usually identifies the service side.
- Protocol is Wireshark's decoder label. TCP means transport is visible, but no application decoder was identified.
- Conversations summarizes host and port pairs. Use it to choose a flow, then verify it in packet details.

## Filters are questions, not answers

| Filter | What it isolates | Why use it |
|---|---|---|
| http | decoded web requests and responses | Identify method, URI, status, Location, and Host fields. |
| dns | name lookups and answers | Connect a hostname to a client and resolved IP address. |
| tcp.flags.syn == 1 && tcp.flags.ack == 0 | connection attempts without ACK set | Test whether traffic resembles a SYN-only flood. |
| ip.addr == x.x.x.x | one candidate host | Correlate the same host across DNS and HTTP after identifying it. |
| tcp.port == N | one service after discovery | Inspect a port found in Conversations; do not guess it first. |

## Port reasoning

- A port is a service endpoint, not proof of malicious activity.
- Compare both sides of a conversation: the client normally uses a changing high port; the server normally listens on the stable service port.
- Use Follow TCP Stream only after selecting a relevant conversation or packet. It reconstructs that selected conversation.
