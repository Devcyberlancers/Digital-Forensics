# Hints

Start broad: HTTP for Aurora, Conversations for unusual TCP services, packet-list patterns for the DoS capture, and Endpoints/Conversations before DNS and HTTP in EvilProgram. Confirm every value in packet details.
