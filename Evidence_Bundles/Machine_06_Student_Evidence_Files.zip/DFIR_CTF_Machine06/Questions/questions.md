# Machine 06: Packet Storm - Investigation Questions

Case: NET-DFIR-2026-0611

Submit the exact pipe-separated evidence values requested in each question. There are no invented flag names.

## Q1 - Evidence Integrity
Verify the evidence image against the supplied hash manifest. Submit only: first_16_sha256_chars.

Hint: Use Wireshark easy-level analysis and confirm packet details.

## Q2 - Aurora Victim And Server
Open aurora.pcapng and start with the packet list. Identify the first web request between the two internal hosts. Submit: client_ip | server_ip | method | request_uri.

Hint: Use Wireshark easy-level analysis and confirm packet details.

## Q3 - Aurora Redirect
Continue from the first Aurora web request. Find the response associated with it, inspect its HTTP fields, and submit: status_code | Location_uri | server_ip.

Hint: Use Wireshark easy-level analysis and confirm packet details.

## Q4 - Aurora Non-HTTP Channel
After documenting Aurora HTTP, open Statistics > Conversations and compare the TCP services between the same two hosts. The lower numbered service is web traffic; investigate the other service in packet details and submit: server_port | client_port | Wireshark_protocol_label.

Hint: Use Wireshark easy-level analysis and confirm packet details.

## Q5 - Blaster Command Shell
Open blaster.pcap. Statistics > Conversations shows the only TCP conversation. Explain the roles: the high port is the client side and the lower port is the service side. Follow that one stream to obtain the command. Submit: client_ip | server_ip | server_port | full_command.

Hint: Use Wireshark medium-level analysis and confirm packet details.

## Q6 - DoS SYN Flood
Open dosattack.pcap. The packet list should look repetitive before you filter it. Test the SYN-only hypothesis with tcp.flags.syn == 1 && tcp.flags.ack == 0. Use the destination column and packet count to submit: SYN_only_packet_count | target_ip | observed_ACK_response_count.

Hint: Use Wireshark medium-level analysis and confirm packet details.

## Q7 - EvilProgram Infected Host
Open evilprogram.pcap. The Conversations view is intentionally noisy, so begin with dns: DNS is the protocol that maps names to addresses. Identify the source that asks for the suspicious update domain, then filter that one candidate host with ip.addr == candidate_ip and http to confirm its executable request. Submit: client_ip | queried_domain | download_uri.

Hint: Use Wireshark medium-level analysis and confirm packet details.

## Q8 - Suspicious Download
Continue in evilprogram.pcap. Inspect the executable download request and its HTTP headers. Submit: method | Host_header | request_uri.

Hint: Use Wireshark medium-level analysis and confirm packet details.

## Q9 - Suspicious DNS Domain
Use the DNS packet for the suspicious update domain in evilprogram.pcap. Expand the answer record and submit: queried_domain | resolved_ipv4.

Hint: Use Wireshark medium-level analysis and confirm packet details.

## Q10 - Packet Storm Timeline Capstone
Create a six-step evidence timeline from your prior answers. Submit these six values in order: redirect_status | Aurora_server_port | Blaster_server_port | SYN_only_count | suspicious_domain | downloaded_filename.

Hint: Use Wireshark hard-level analysis and confirm packet details.
