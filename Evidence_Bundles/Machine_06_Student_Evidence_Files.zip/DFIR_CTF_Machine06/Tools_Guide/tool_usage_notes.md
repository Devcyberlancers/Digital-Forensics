# Machine 06 Tools Guide

## Opening PCAPs in Wireshark
Open one capture at a time. Use packet list, protocol details, and raw bytes.

## HTTP filtering
Use http and inspect method, Host, URI, response code, and Location.

## DNS filtering
Use dns, inspect query names, and correlate the query host with HTTP.

## Conversations and endpoints
Use Statistics > Conversations and Statistics > Endpoints as leads, then confirm in packets.

## TCP stream review
Select a relevant TCP packet and use Follow TCP Stream. Record text actually observed.

## TCP flag and SYN-flood analysis
Use tcp.flags.syn == 1 && tcp.flags.ack == 0. Compare destinations and missing normal completion behavior.

## Timeline building
Write one observation per capture and place them in evidence-supported order.

## Flag normalization
Use exact braces, underscores, and case for derived flags. Whitespace is normalized but partial answers are rejected.
