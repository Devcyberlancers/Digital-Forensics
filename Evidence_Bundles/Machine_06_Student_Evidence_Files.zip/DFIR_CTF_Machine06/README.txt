DFIR CTF Machine 06 - Packet Storm

Beginner-friendly Wireshark and deep packet inspection investigation.

Start:
1. Open WebApp/index.html.
2. Click Start Investigation.
3. Open the PCAP files in Wireshark.
4. Use the provided filter guide to inspect HTTP, DNS, TCP streams, and TCP flags.
5. Record answers in Questions/student_answer_log.md and in the web app.
