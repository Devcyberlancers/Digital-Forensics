# Machine 06: Packet Storm

Case: NET-DFIR-2026-0611

## Story / Scenario
The SOC collected four captures covering Aurora browser-exploit traffic, a Blaster command shell, a SYN flood, and EvilProgram/Virtumonde activity.

## Learning Objectives
- Open PCAPs in Wireshark and use HTTP, DNS, streams, endpoints, conversations, and TCP flags.
- Document observed packet facts before reaching conclusions.
- Correlate four captures into an incident timeline.

## Student Mission
Use Wireshark to record the requested observations and submit exact derived responses in the WebApp.
