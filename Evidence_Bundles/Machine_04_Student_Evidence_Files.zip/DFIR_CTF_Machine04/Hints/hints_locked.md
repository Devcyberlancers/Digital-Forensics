# Hints

Use the WebApp hint buttons if you get stuck. Hints point to methods and artifacts, not final answers.
