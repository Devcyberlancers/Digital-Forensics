# Machine 04: Signal in the Noise - Investigation Questions

## Case Number: SIG-DFIR-2026-0404

## Story / Scenario

A media contractor is suspected of hiding delivery instructions across ordinary-looking image and audio files. Each answer must be derived from observed evidence rather than copied from a visible flag string.

## Learning Objectives

- Verify evidence integrity.
- Inspect metadata, image payloads, LSB pixels, spectrogram clues, reversed audio, access-register evidence, and a final lock.
- Correlate earlier findings into a final analyst conclusion.

> Total Questions: 10  
> Total Flags: 6  
> Estimated Time: 35-55 minutes  
> Flag Format: `FLAG{text_with_underscores}`

### Q1 - Evidence Integrity Verification (5 pts)
**Difficulty:** Easy
**Tool:** sha256sum / manifest comparison

Compute the SHA-256 hash of `Evidence/Disk/signal_lab.vhd`, compare it with `Hashes/SHA256SUMS.txt`, and submit only the first 16 hash characters. Submit format: `<first_16_sha256_chars>`.

### Q2 - Image Metadata Clue (5 pts)
**Difficulty:** Easy
**Tool:** ExifTool + xxd hex decode

Inspect `exhibit_poster.png` metadata and verify the artist against `contractor_profile.txt`. First derive `<contractor_initials>` from the verified full name. Then derive `<decoded_token>` by decoding `MetadataTokenHex` with `xxd -r -p`. Submit exactly: `FLAG{metadata_<contractor_initials>_<decoded_token>}`.

### Q3 - Steghide Password Lead (5 pts)
**Difficulty:** Easy
**Tool:** Analyst note + artifact correlation

Review `analyst_note.txt`, resolve botanical channel 03 in `passphrase_rotation.csv`, and correlate it with `lobby_photo.bmp`. Derive the active passphrase. Submit exactly: `<active_passphrase>`.

### Q4 - Image Payload Extraction (5 pts)
**Difficulty:** Easy
**Tool:** Steghide + payload review

Use the Q3 password to inspect `lobby_photo.bmp` and recover the payload. Derive `<source_image_stem>` from `Source image: lobby_photo.bmp`, `<password>` from Q3, and `<payload_state>` from `Payload state`. Submit exactly: `FLAG{payload_<source_image_stem>_<password>_<payload_state>}`.

### Q5 - Pixel LSB Message (8 pts)
**Difficulty:** Medium
**Tool:** Python LSB helper + script review

Read `lsb_extract_helper.py`, then run it against `pixel_noise.png`. Convert the recovered phrase to lowercase with spaces replaced by underscores. Submit exactly: `FLAG{lsb_<recovered_phrase_with_underscores>}`.

### Q6 - Spectrogram Phrase (8 pts)
**Difficulty:** Medium
**Tool:** Sonic Visualizer

Open `hidden_broadcast.wav` in Sonic Visualizer, add a spectrogram layer, and record the visible phrase exactly. Submit format: `<spectrogram_phrase_exactly_as_seen>`. This is a lead for Q9, not a flag.

### Q7 - Audio Validation Marker (8 pts)
**Difficulty:** Medium
**Tool:** strings / hex editor

After Q6, inspect `hidden_broadcast.wav` with strings or a hex editor and locate `Validation clue`. Derive `<validation_phrase>` from that value only; normalize it to lowercase with underscores. Use Q6 and `stego_timeline.csv` only to corroborate the sequence. Submit exactly: `FLAG{audio_<validation_phrase_with_underscores>}`.

### Q8 - Reversed Audio Message (8 pts)
**Difficulty:** Medium
**Tool:** Audacity

Open `reversed_clip.wav` in Audacity, select the full track, apply Reverse, and listen. Convert the recovered clue to lowercase with spaces removed. Submit exactly: `FLAG{audio_reversed_<recovered_clue_without_spaces>}`.

### Q9 - Access Register Correlation (8 pts)
**Difficulty:** Medium
**Tool:** CSV review + evidence correlation

Use Q6 location and Q8 gate to find the one matching row in `access_register.csv`; ignore the decoy. Submit exactly: `<meeting_location> | <gate> | <HH:MM>`.

### Q10 - Final Signal Lock (12 pts)
**Difficulty:** Hard
**Tool:** Evidence correlation

Build the final flag from your prior answers: `<password>` from Q3, `<location_without_spaces>` from Q6, `<gate_without_spaces>` from Q8, and `<time_without_colon>` from Q9. Submit exactly: `FLAG{signal_<Q3_password>_<Q6_location>_<Q8_gate>_<Q9_time>}`.

## Scoring

| Difficulty | Questions | Points |
|---|---|---:|
| Easy | Q1-Q4 | 20 |
| Medium | Q5-Q9 | 40 |
| Hard | Q10 | 12 |
| Total | 10 questions | 72 |
