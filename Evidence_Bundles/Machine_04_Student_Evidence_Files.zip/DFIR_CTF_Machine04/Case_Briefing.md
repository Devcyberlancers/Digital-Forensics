# Case Briefing: Machine 04 - Signal in the Noise

## Incident

Case SIG-DFIR-2026-0404 begins after a media contractor, Maya Varma, delivered a gallery media packet that appears normal at first glance. The security team suspects that delivery instructions were hidden across image metadata, image payloads, pixel-level data, audio spectrograms, reversed audio, and encoded text.

Your role is to investigate the packet, recover each clue using beginner-friendly forensic tools, and decide whether the media artifacts form a deliberate hidden communication chain. Treat the case as a media-forensics triage: do not execute unknown content, preserve evidence paths, and explain how each clue supports the next step.

## Case Background

Pinnacle Corp's events team received a compressed "gallery refresh" packet from an external media contractor. The packet was intended to contain harmless promotional media for an evening exhibit, but the SOC noticed unusual naming patterns, repeated references to "signal" and "channel", and a short audio file that did not match the expected deliverables.

The first analyst believes the contractor may have split instructions across multiple media artifacts to avoid obvious detection. Your job is to recover the chain in order: poster metadata, lobby image payload, pixel-level message, audio spectrogram, audio validation marker, reversed audio clue, encoded meeting card, and final signal lock.

## Point of Contact

- Primary SOC Contact: Nisha Rao, DFIR Analyst
- Email: nisha.rao@pinnacle-corp.local
- Phone Extension: 4421
- Escalation Queue: SOC-MEDIA-FORENSICS
- Evidence Owner: Corporate Security Evidence Desk
- Handling Note: Contact the SOC only after recording the artifact path, tool used, observed value, and derived answer for each question.

## Mission

1. Verify evidence integrity before analysis.
2. Inspect image metadata for attribution and hidden clues.
3. Use supporting notes to identify likely steganography passwords.
4. Extract and interpret image payloads with Steghide-style workflows.
5. Understand beginner LSB steganography by reviewing and running a helper script.
6. Use Sonic Visualizer to recover spectrogram text from audio.
7. Inspect audio files with strings or a hex editor for validation markers.
8. Reverse audio to recover spoken clues.
9. Correlate the spectrogram location and reversed-audio gate clue against the access register.
10. Correlate image, audio, location, and final-lock evidence into a final conclusion.

## Investigation Rule

- Record the artifact path used for every answer.
- Prefer tool evidence over plain file browsing.
- Derived flags must be built from observed fields, phrases, or correlated values.
- Instructor-only WebApp sections are not required for student solving.
