# Machine 04 Tools Guide

## Hashing

Use `sha256sum Evidence/Disk/signal_lab.vhd` and compare the full hash with `Hashes/SHA256SUMS.txt`.

## ExifTool / Metadata

Use `exiftool Evidence/Expanded_Files/Images/exhibit_poster.png` to review author, comment, and custom metadata fields.

## Steghide Extraction

Use `steghide extract -sf Evidence/Expanded_Files/Images/lobby_photo.bmp -p orchid` and locate `STEGO_PAYLOAD_START` in the recovered payload.

## LSB Helper

Read `Evidence/Expanded_Files/Tools/lsb_extract_helper.py` before running it. The script extracts the least significant bit from image bytes, groups bits into bytes, stops at a null byte, and prints the hidden phrase.

## Sonic Visualizer

Open `Evidence/Expanded_Files/Audio/hidden_broadcast.wav`, add a spectrogram layer, adjust contrast if needed, and record the visible phrase.

## Strings / Hex Editor

Use `strings Evidence/Expanded_Files/Audio/hidden_broadcast.wav` or a hex editor to locate textual markers appended to the WAV.

## Audacity Audio Reversal

Audacity: import `Evidence/Expanded_Files/Audio/reversed_clip.wav`, select the track, apply Reverse, and listen.

## Access Register Correlation

Use the Q6 spectrogram phrase and Q8 reversed-audio gate clue to identify the matching row in `Evidence/Expanded_Files/Location/access_register.csv`.
