from pathlib import Path
from PIL import Image

img = Image.open(Path(__file__).resolve().parents[1] / "Images" / "pixel_noise.png").convert("RGB")
bits = []
for channel in img.tobytes():
    # The hidden message is stored in the least significant bit of each color byte.
    bits.append(channel & 1)

chars = []
for i in range(0, len(bits), 8):
    byte = 0
    for bit in bits[i:i+8]:
        byte = (byte << 1) | bit
    if byte == 0:
        break
    chars.append(chr(byte))

print("".join(chars))
