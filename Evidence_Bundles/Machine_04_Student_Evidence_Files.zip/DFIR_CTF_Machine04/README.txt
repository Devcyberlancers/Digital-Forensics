DFIR CTF Machine 04 - Signal in the Noise

Story / Scenario:
A media contractor is suspected of hiding delivery instructions inside ordinary gallery media files. Your task is to verify the evidence, recover clues from image and audio artifacts, and correlate the findings into a final signal-lock conclusion.

Start:
1. Open the WebApp and click Start Investigation.
2. Download or open the student evidence.
3. Begin with Questions/questions.md.
4. Record answers in Questions/student_answer_log.md and submit them in the WebApp Questions tab.

Investigation Rules:
- Do not treat one file as enough proof when the question asks for correlation.
- Derived flags are built from observed clues. Student evidence does not contain submit-ready flags.
- Evidence Explorer and Walkthrough are instructor reference areas.

Point of Contact:
- Primary SOC Contact: Nisha Rao, DFIR Analyst
- Email: nisha.rao@pinnacle-corp.local
- Phone Extension: 4421
- Escalation Queue: SOC-MEDIA-FORENSICS
