# Call Shadows v4

1. Read Case_Briefing.md.
2. Read Tools_Guide/tool_usage_notes.md and install the listed GUI tools.
3. Verify Evidence/Case_Review.sqlite, then work through the web-app questions in order.
4. Record supporting row IDs in Questions/student_answer_log.md.

Extract the entire package before opening files. Relative paths begin in this folder. SQLite and CSV exports work on Windows and Kali. No raw E01 image is supplied or needed. No code needs to be written.
