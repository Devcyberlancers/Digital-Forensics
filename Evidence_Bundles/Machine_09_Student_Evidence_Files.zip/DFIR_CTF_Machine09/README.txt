Call Shadows v4 — start with START_HERE.md. All students use GUI tools.
