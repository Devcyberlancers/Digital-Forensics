# Call Shadows — artifact investigation v4

No student programming, SQL, macros, spreadsheets or new software installation is required. Use your existing Firefox browser, text viewer and archive manager. DB Browser is an optional independent route, not a mandatory installation. Extract the complete new evidence pack first. Keep old and new evidence in separate folders: the database and checksums have changed.

## Q1–Q4: establish the starting facts
The File Inspector can hash the database in Q1. For Q2/Q3/Q4 the Local CSV Reader can inspect the matching Tables CSVs without DB Browser. On Kali, open these bundled HTML tools in Firefox.

Verify Case_Review.sqlite against Hashes/SHA256SUMS.txt with the existing hash utility. The included File Inspector can calculate a local SHA-256 in a current browser as an alternative to QuickHash. The existing DB Browser opens the evidence database through Browse Data; clear filters between tables. Q4's Local CSV Reader remains an option for document_register.csv. No typed SQL is needed.

## Q5: portable phone acquisition report, SQLite and vCard contact
Open Evidence/Phone/acquisition_report.html in Firefox. It is a portable, read-only report exported from the supplied SQLite database. Choose the handset/account matching Q2, the required call type, inclusive From and exclusive Before UTC fields, and Connected only. Read the resulting call cards and compare totals with a calculator or by hand. The report never aggregates peers or produces flags. Open contacts.vcf in the normal text editor to attribute the winning number. The native SQLite route below is optional.

Open Evidence/Phone/calllog.db in the existing DB Browser. phone_accounts maps the acquired exhibit and IMEI to its account_id. calls contains Android-style raw fields: number, date (Unix milliseconds), duration (seconds), type and phone_account_id. Type 1 is incoming, 2 outgoing, 3 missed. Positive duration is needed for a connected call. calls_readable is an examiner-provided UTC view of those raw dates, not a separately edited CSV. Use Browse Data filters and sort the whole view. Open contacts.vcf with the default text viewer and compare full TEL values with FN names. Use a normal calculator or hand arithmetic to compare the eligible groups. No aggregation script is required.

## Q6: listen and corroborate
Open VM_1952.wav with the default audio player, or Firefox's local media player. Replay the message to distinguish corrections and excluded choices. Open Evidence/Maps/entrance_plan.pdf in Firefox's built-in PDF viewer. The voice note is a synthetic follow-up excerpt; its playback length is not the duration of an entire network call. The plan is schematic. Neither artifact alone proves attendance.

## Q7: recover genuine PDF bytes
Open Evidence/Recovery/recycle_export.zip with the default archive manager and extract it into a Working folder. On Windows enable View > Show > Hidden items to see $Recycle.Bin; Kali does not hide a folder merely because its name begins with $. Inside the exported SID folder, $R files contain recovered data and $I files contain binary Recycle Bin v2 metadata. Their matching extension does not mean an $I file is a PDF.

Use Open File Inspector in Q7 to choose each recovered $R PDF. It calculates exact byte length and SHA-256 locally without modifying or uploading the file. Compare both against DOC-41's full content_sha256 and byte_length from the original document register. Another document has the same length, so a filename or title is insufficient. Open the authenticated PDF in the default browser/PDF viewer and read its printed dispatch reference. You can optionally inspect the $I companion using the same inspector; it parses the binary size, FILETIME and UTF-16 original path. The inspector does not decide which file answers the question.

## Q8: password-protected handoff archive
Read Evidence/Recovery/handoff_password_note.txt. It specifies how to assemble the lowercase password from facts already established in Q5–Q7; there is no brute force or script. Open handoff.zip in the default archive manager and choose Extract. Enter the derived password when prompted; listing filenames alone does not decrypt the content. The archive uses standard traditional ZIP encryption for broad default-tool compatibility, not strong production encryption.

Open handoff.eml in a text viewer or existing mail viewer. Check the sender against the contact export. Open journal_receipt.xml in a text viewer or browser; it is a decoded acquisition receipt. Match the authenticated document hash and exact file generation, distinguish CLOSE from FILE_DELETE, and preserve the original source timestamp for Q10. No FLAG string is embedded in the receipt.

## Q9–Q10: independent corroboration
The original Tables CSVs and Case_Review.sqlite remain useful for hard-question correlation. The Local CSV Reader can inspect them if preferred. Use valid badge assignments, granted access events and valid clock checks. true UTC = observed UTC - offset_seconds. Call end = start + duration. An NTFS-style generation requires volume + frn + sequence; filenames and FRNs alone can be reused. Compare the acquired handset log with the FINAL network revision and decrypted receipt instead of trusting one source.

All artifacts are fictional training material with valid file structures. The acquisition is not claimed to be a raw phone image or raw NTFS filesystem. The call log has Android-style call records plus explicitly labelled examiner mapping/view tables. No real person, interception or extracted private device data is represented.
