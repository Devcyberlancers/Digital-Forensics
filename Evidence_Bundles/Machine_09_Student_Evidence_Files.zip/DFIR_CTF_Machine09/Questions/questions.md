# Machine 09: Call Shadows — Questions (v4)

4 easy · 4 medium · 2 hard · 72 points. All evidence paths are relative to DFIR_CTF_Machine09.

Use the included browser helpers and existing viewers; no programming or new application installation is required.

## Q1 — Verify the evidence database (Easy, 5 points)

Calculate the SHA-256 of Evidence/Case_Review.sqlite with the File Inspector or your existing hash utility.
Compare the complete value with its entry in Hashes/SHA256SUMS.txt.
If they match, submit the first 16 hash characters.

**Tool to be used:** Existing SHA-256 utility or included File Inspector

**Answer format:** `<first16_sha256>`

**Hint:** Choose SHA-256 and hash the extracted database file, not the ZIP or a CSV export.

## Q2 — Identify the acquired handset (Easy, 5 points)

Inspect acquisition_register in Case_Review.sqlite, or load Evidence/Tables/acquisition_register.csv in the Local CSV Reader.
Find the handset recorded as exhibit EV09-H01.
What is its IMEI? Keep all digits exactly as recorded.

**Tool to be used:** Existing DB Browser or Local CSV Reader

**Answer format:** `<15_digit_imei>`

**Hint:** Filter exhibit to EV09-H01; do not use the second handset or the workstation record.

## Q3 — Check the workstation clock (Easy, 5 points)

In the clock_checks table or Evidence/Tables/clock_checks.csv, find the WS-09 calibration valid on 9 June 2026 at 19:00 UTC.
What is its signed offset_seconds value?
Submit the number without a plus sign; the field definition explains how to correct it.

**Tool to be used:** Existing DB Browser or Local CSV Reader

**Answer format:** `<signed_seconds>`

**Hint:** Read the validity dates before choosing between the two WS-09 calibrations.

## Q4 — Establish the document size (Easy, 5 points)

Open the Local CSV Reader from this question and load Evidence/Tables/document_register.csv.
Locate document DOC-41, the dispatch schedule requested for review.
What is its byte_length? Submit digits only, without a separator or unit.

**Tool to be used:** Existing browser - Local CSV Reader

**Answer format:** `<bytes>`

**Hint:** Use the document_id rather than picking another record with the same size.

## Q5 — Reconstruct the handset contact (Medium, 8 points)

Open Evidence/Phone/acquisition_report.html in Firefox; its source calllog.db is included for independent review.
Select the Q2 handset and compare outgoing, positive-duration calls on 9 June from 19:00 up to but excluding 20:00 UTC.
Match the strongest peer by total seconds to Evidence/Phone/contacts.vcf.
Submit the contact name with underscores and the total connected seconds.

**Tool to be used:** Firefox acquisition report; text viewer; Calculator (DB Browser optional)

**Answer format:** `FLAG{contact_<first_last>_<total_seconds>}`

**Hint:** The readable view preserves the raw call dates in UTC. Compare duration rather than frequency, then corroborate the number with the vCard.

## Q6 — Resolve the entrance from the voice message (Medium, 8 points)

Listen to Evidence/Phone/VM_1952.wav, the saved follow-up message from the Q5 contact.
Distinguish the entrance actually used from the cancelled location and wrong vehicle gate.
Check Evidence/Maps/entrance_plan.pdf and submit the area_code with the entrance ID.

**Tool to be used:** Default browser/audio player; built-in PDF viewer

**Answer format:** `<area_code>_<entrance_id>`

**Hint:** The speaker corrects an earlier instruction. Match the pedestrian entrance to the plan rather than accepting the first location mentioned.

## Q7 — Recover and authenticate the deleted dispatch PDF (Medium, 8 points)

Extract Evidence/Recovery/recycle_export.zip into a Working folder using the archive manager.
Authenticate the recovered $R PDF against DOC-41’s complete content_sha256 and Q4 size from document_register.
Open only the matching PDF and report its dispatch reference; $I files are metadata, not document content.

**Tool to be used:** Default archive manager; browser PDF viewer; included File Inspector

**Answer format:** `<dispatch_reference>`

**Hint:** Two candidates share the same size. Use Open File Inspector to hash each $R file; a plausible filename or visible title alone is not authentication.

## Q8 — Unlock and validate the handoff receipt (Medium, 8 points)

Read Evidence/Recovery/handoff_password_note.txt and unlock handoff.zip using facts from Q5, Q6 and Q7.
Check handoff.eml, then authenticate the document hash in journal_receipt.xml against the Q7 PDF.
Submit receipt_ref for its FILE_DELETE record in the original file generation; reject CLOSE-only and reused-generation records.

**Tool to be used:** Default archive manager; text viewer or browser

**Answer format:** `<receipt_reference>`

**Hint:** The ZIP password uses the dispatch reference, the last four digits of the established peer number, and the actual entrance ID, all lowercase.

## Q9 — Establish a corroborated shared-access window (Hard, 10 points)

Link the Q2 handset owner and Q5 contact to badges valid on 9 June using acquisition_register, peer_directory and badge_assignments.
Use GRANTED access_events, correct ACCESS-E timestamps with clock_checks, and find their overlapping visit in Q6’s area_code (not the entrance ID) via site_zones.
Submit the area_code and shared UTC window in HHMM; a voice message and common-area access do not prove a face-to-face meeting.

**Tool to be used:** DB Browser for SQLite or Local CSV Reader; Calculator; browser map

**Answer format:** `FLAG{overlap_<area_code>_<start_HHMM>_<end_HHMM>}`

**Hint:** Reject expired badges and denied entries. Correct both visits first, then choose the later entry and earlier exit.

## Q10 — Measure the post-call deletion gap (Hard, 10 points)

Find the final connected outgoing call to the Q5 contact in the Q2 handset report/log during 19:00–20:00 UTC; check its start and duration against the FINAL network record.
Use the Q7 document hash to establish its file identity, then correct the Q8 receipt deletion time with the Q3 workstation offset.
Measure deletion UTC minus call-end UTC and combine the frn, sequence and gap; do not use the Q9 access-window boundary.

**Tool to be used:** Firefox acquisition report; Local CSV Reader; Calculator (DB Browser optional)

**Answer format:** `FLAG{closure_<frn>_<sequence>_<gap_seconds>}`

**Hint:** The handset log is an independent check on an obsolete network revision. Add call duration before correcting and comparing the deletion timestamp.
