# Student answer log — Call Shadows (v4)

Student name: ____________________  |  Date: ____________________

Record your own findings below. Use questions.md for the full question, tool and hint. Keep original evidence unchanged; save recovered files in Working.

## Submission checklist

| Question | Difficulty | Points | Answer recorded |
|---|---|---:|---|
| Q1 — Verify the evidence database | Easy | 5 | [ ] |
| Q2 — Identify the acquired handset | Easy | 5 | [ ] |
| Q3 — Check the workstation clock | Easy | 5 | [ ] |
| Q4 — Establish the document size | Easy | 5 | [ ] |
| Q5 — Reconstruct the handset contact | Medium | 8 | [ ] |
| Q6 — Resolve the entrance from the voice message | Medium | 8 | [ ] |
| Q7 — Recover and authenticate the deleted dispatch PDF | Medium | 8 | [ ] |
| Q8 — Unlock and validate the handoff receipt | Medium | 8 | [ ] |
| Q9 — Establish a corroborated shared-access window | Hard | 10 | [ ] |
| Q10 — Measure the post-call deletion gap | Hard | 10 | [ ] |

## Investigation records

### Q1 — Verify the evidence database

**Answer format:** `<first16_sha256>`

**My answer:** ____________________

**Evidence path(s) and record identifier(s):**

- 

**Tool, filters and method used:**

- 

**Observation and reasoning (include arithmetic or clock correction where relevant):**

- 

**Screenshot or saved output reference:** ____________________

### Q2 — Identify the acquired handset

**Answer format:** `<15_digit_imei>`

**My answer:** ____________________

**Evidence path(s) and record identifier(s):**

- 

**Tool, filters and method used:**

- 

**Observation and reasoning (include arithmetic or clock correction where relevant):**

- 

**Screenshot or saved output reference:** ____________________

### Q3 — Check the workstation clock

**Answer format:** `<signed_seconds>`

**My answer:** ____________________

**Evidence path(s) and record identifier(s):**

- 

**Tool, filters and method used:**

- 

**Observation and reasoning (include arithmetic or clock correction where relevant):**

- 

**Screenshot or saved output reference:** ____________________

### Q4 — Establish the document size

**Answer format:** `<bytes>`

**My answer:** ____________________

**Evidence path(s) and record identifier(s):**

- 

**Tool, filters and method used:**

- 

**Observation and reasoning (include arithmetic or clock correction where relevant):**

- 

**Screenshot or saved output reference:** ____________________

### Q5 — Reconstruct the handset contact

**Answer format:** `FLAG{contact_<first_last>_<total_seconds>}`

**My answer:** ____________________

**Evidence path(s) and record identifier(s):**

- 

**Tool, filters and method used:**

- 

**Observation and reasoning (include arithmetic or clock correction where relevant):**

- 

**Screenshot or saved output reference:** ____________________

### Q6 — Resolve the entrance from the voice message

**Answer format:** `<area_code>_<entrance_id>`

**My answer:** ____________________

**Evidence path(s) and record identifier(s):**

- 

**Tool, filters and method used:**

- 

**Observation and reasoning (include arithmetic or clock correction where relevant):**

- 

**Screenshot or saved output reference:** ____________________

### Q7 — Recover and authenticate the deleted dispatch PDF

**Answer format:** `<dispatch_reference>`

**My answer:** ____________________

**Evidence path(s) and record identifier(s):**

- 

**Tool, filters and method used:**

- 

**Observation and reasoning (include arithmetic or clock correction where relevant):**

- 

**Screenshot or saved output reference:** ____________________

### Q8 — Unlock and validate the handoff receipt

**Answer format:** `<receipt_reference>`

**My answer:** ____________________

**Evidence path(s) and record identifier(s):**

- 

**Tool, filters and method used:**

- 

**Observation and reasoning (include arithmetic or clock correction where relevant):**

- 

**Screenshot or saved output reference:** ____________________

### Q9 — Establish a corroborated shared-access window

**Answer format:** `FLAG{overlap_<area_code>_<start_HHMM>_<end_HHMM>}`

**My answer:** ____________________

**Evidence path(s) and record identifier(s):**

- 

**Tool, filters and method used:**

- 

**Observation and reasoning (include arithmetic or clock correction where relevant):**

- 

**Screenshot or saved output reference:** ____________________

### Q10 — Measure the post-call deletion gap

**Answer format:** `FLAG{closure_<frn>_<sequence>_<gap_seconds>}`

**My answer:** ____________________

**Evidence path(s) and record identifier(s):**

- 

**Tool, filters and method used:**

- 

**Observation and reasoning (include arithmetic or clock correction where relevant):**

- 

**Screenshot or saved output reference:** ____________________

## Final investigation conclusion

Summarize the supported contact, location, document and timing findings. Distinguish what the evidence supports from what it cannot establish.

Conclusion: ____________________

Limitations: ____________________
