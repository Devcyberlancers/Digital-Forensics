# Single hints

Q1: Choose SHA-256 and hash the extracted database file, not the ZIP or a CSV export.

Q2: Filter exhibit to EV09-H01; do not use the second handset or the workstation record.

Q3: Read the validity dates before choosing between the two WS-09 calibrations.

Q4: Use the document_id rather than picking another record with the same size.

Q5: The readable view preserves the raw call dates in UTC. Compare duration rather than frequency, then corroborate the number with the vCard.

Q6: The speaker corrects an earlier instruction. Match the pedestrian entrance to the plan rather than accepting the first location mentioned.

Q7: Two candidates share the same size. Use Open File Inspector to hash each $R file; a plausible filename or visible title alone is not authentication.

Q8: The ZIP password uses the dispatch reference, the last four digits of the established peer number, and the actual entrance ID, all lowercase.

Q9: Reject expired badges and denied entries. Correct both visits first, then choose the later entry and earlier exit.

Q10: The handset log is an independent check on an obsolete network revision. Add call duration before correcting and comparing the deletion timestamp.