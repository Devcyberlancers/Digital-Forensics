# Call Shadows

Case CDR-DFIR-2026-0909 · 9 June 2026

A call-record export and filesystem journal are associated with a suspected meeting. Investigators need to connect device identity, tower information and recurring contacts without treating one location record as conclusive proof.

The journal adds another thread: files were renamed or removed around the investigation context. Follow both the communications and file-history evidence before using the supplied records to build a defensible timeline. The investigation remains open: distinguish what the records support from what they cannot establish.

Exhibit EV09-H01 is the handset under review; DOC-41 is the requested dispatch document. Examine 19:00–20:00 UTC on 9 June for the call pattern. Do not assume every source clock is synchronized.

All persons and events are fictional. This is a structured export-based forensic exercise, not a real E01/NTFS image. Journal rows are synthetic decoded records, not a raw $UsnJrnl stream.
