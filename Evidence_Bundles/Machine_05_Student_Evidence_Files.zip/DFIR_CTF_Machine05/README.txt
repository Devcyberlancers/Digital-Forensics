MACHINE 05 - REGISTRY SHADOWS
================================

This revision uses a genuine partitioned forensic disk image.

Start:
1. Open the web app and click Start Investigation.
2. Work from Evidence/Disk/registry_ws512.img.
3. Verify the image SHA-256 against Hashes/SHA256SUMS.txt.
4. Use mmls, fls, istat, and icat directly against the image.
5. Extract artifacts into a separate Working directory.
6. Repair only working copies, never the original image.
7. Record every answer in Questions/student_answer_log.md and the web app.

Important:
- Prepared Sleuth Kit output files are intentionally not supplied.
- The partition begins at an offset students must discover with mmls.
- Registry artifacts are synthetic Windows .reg exports stored inside the image.
- All identities and evidence are fictional and intended for education.
