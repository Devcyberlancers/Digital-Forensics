# Machine 05: Registry Shadows
## Investigation Questions

**Questions:** 10  
**Flags:** 6  
**Maximum score:** 72  
**Estimated time:** 60-90 minutes

## Required Working Practice

- Analyze `Evidence/Disk/registry_ws512.img` directly.
- Create a separate `Working` directory for extracted files.
- Do not modify the original disk image.
- Record the command, metadata address, source path, and observation for every answer.

### Q1 - Evidence Integrity Verification (5 points)
**Difficulty:** Easy  
**Primary tool:** sha256sum

Calculate the SHA-256 hash of `Evidence/Disk/registry_ws512.img`. Compare the complete result with the matching entry in `Hashes/SHA256SUMS.txt`. Submit only the first 16 hash characters: `<first_16_sha256_chars>`.

### Q2 - Partition Start Sector (5 points)
**Difficulty:** Easy  
**Primary tool:** Sleuth Kit mmls

Use `mmls` to read the disk partition table. Submit the start sector of the active FAT partition that must be passed to later Sleuth Kit commands.

### Q3 - Suspicious Startup Artifact (5 points)
**Difficulty:** Easy  
**Primary tool:** Sleuth Kit fls

Use `fls` to enumerate the filesystem from the partition offset. Identify the executable-looking file placed in the user's autostart location. Submit: `filename | parent_path | metadata_address`.

### Q4 - Filesystem Timestamp (5 points)
**Difficulty:** Easy  
**Primary tool:** Sleuth Kit istat

Use `istat` on the metadata address from Q3. Prove when the autostart artifact was created by submitting: `YYYY-MM-DD HH:MM:SS | metadata_address | full_path`.

### Q5 - Startup Directory Validation (8 points)
**Difficulty:** Medium  
**Primary tool:** Sleuth Kit icat

Extract the validation record from the same autostart directory. Use the literal context token `startup`; remove the artifact extension and separators; use only the local time as HHMMSS. Submit: `FLAG{startup_<artifactbase_normalized>_<hhmmss>}`.

### Q6 - Registry Run Key (8 points)
**Difficulty:** Medium  
**Primary tool:** Sleuth Kit icat + registry export analysis

Recover the user's Run key export. Use literal `runkey`; normalize the Run value name and target basename by removing spaces, separators, and file extensions. Submit: `FLAG{runkey_<valuename_normalized>_<artifactbase_normalized>}`.

### Q7 - RecentDocs Payload Trail (8 points)
**Difficulty:** Medium  
**Primary tool:** Sleuth Kit icat + registry export analysis

Recover and inspect the RecentDocs export. Use the MRUList token for the most recent renamed payload, then normalize the renamed payload and Startup basename by removing separators and extensions. Submit: `FLAG{recentdocs_mru_<mru_token>_<renamedpayload_normalized>_<artifactbase_normalized>}`.

### Q8 - USB Registry Correlation (8 points)
**Difficulty:** Medium  
**Primary tool:** Sleuth Kit icat + USBSTOR analysis

Recover the USBSTOR export and decide whether removable-media activity happened before the RecentDocs/Startup trail. Normalize the USB vendor/product family by removing separators; use only LastConnected as HHMMSS. Submit: `FLAG{usb_<vendorproduct_normalized>_<hhmmss>}`.

### Q9 - Extract and Repair the Payload (10 points)
**Difficulty:** Hard  
**Primary tool:** Sleuth Kit icat + hex editor

Extract the suspicious Startup binary from Q3, inspect its first bytes, repair the damaged archive signature on a working copy, and read the recovered note. Normalize the expected header and payload basename, then submit: `FLAG{zip_<header_token>_<payloadfamily_normalized>_<repair_status>}`.

### Q10 - Deleted Case Closure (10 points)
**Difficulty:** Hard  
**Primary tool:** Sleuth Kit fls/icat + timeline correlation

Search deleted entries, recover the closure note, and use it as a final analyst checklist. Normalize each component by removing spaces, separators, and file extensions; retain underscores only as the flag-token separators. Submit: `FLAG{registry_<persistence>_<artifactbase_normalized>_<usbtime_hhmmss>_<header_token>}`.
