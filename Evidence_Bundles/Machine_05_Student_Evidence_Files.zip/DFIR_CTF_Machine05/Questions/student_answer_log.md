# Student Investigation Log

| Question | Command / tool | Metadata address | Artifact path | Observation | Submitted answer |
|---|---|---|---|---|---|
| Q1 | | | | | |
| Q2 | | | | | |
| Q3 | | | | | |
| Q4 | | | | | |
| Q5 | | | | | |
| Q6 | | | | | |
| Q7 | | | | | |
| Q8 | | | | | |
| Q9 | | | | | |
| Q10 | | | | | |
