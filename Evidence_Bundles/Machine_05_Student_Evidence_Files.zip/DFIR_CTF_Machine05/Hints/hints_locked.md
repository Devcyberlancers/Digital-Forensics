# Progressive Hints

1. Start with `mmls`; do not assume an offset.
2. Use `fls -r -p` to preserve full paths.
3. `istat` and `icat` require the metadata address printed by `fls`.
4. The relevant registry artifacts are stored in the user profile and Windows config directory.
5. Include deleted entries when searching for the final note.
