# Machine 05 Tool Guide

Run commands from the machine root or replace `$IMG` with the full image path.

```bash
IMG="Evidence/Disk/registry_ws512.img"
mkdir -p Working
```

## How This Workflow Works

This lab uses a captured disk image. You are not opening normal files directly
from Windows Explorer. Instead, you use Sleuth Kit to examine the image in a
forensic way:

1. `mmls` reads the disk partition table.
2. `fls` lists files inside a filesystem.
3. `istat` shows metadata for one file record.
4. `icat` extracts the content of one file record.

Important terms:

- **Offset**: the sector where the filesystem begins inside the disk image.
  You discover it using `mmls`. In later commands, `-o <OFFSET>` tells Sleuth
  Kit where to start reading the filesystem.
- **Metadata address**: the file record number printed by `fls` before the
  colon. Example: `r/r 1159: path/file.bin` means `1159` is the address to use
  with `istat` or `icat`.
- **Working folder**: a safe folder where you store recovered files. Do not
  modify the original disk image.
- **Redirection (`>`)**: saves command output to a file. Example:
  `icat ... > Working/file.bin` extracts a file from the image into `Working`.

## Integrity

```bash
sha256sum "$IMG"
cat Hashes/SHA256SUMS.txt
```

## Partition Discovery

```bash
mmls "$IMG"
```

What it does: reads the partition table. The `Start` sector from this output is
the offset you must reuse with `fls`, `istat`, and `icat`.

## Filesystem Enumeration

After discovering the partition start sector:

```bash
fls -r -p -o <OFFSET> "$IMG"
fls -r -d -p -o <OFFSET> "$IMG"
```

What it does:
- `-o <OFFSET>` tells Sleuth Kit where the filesystem begins.
- `-r` searches recursively.
- `-p` prints full paths so you can prove artifact location.
- `-d` shows deleted entries for recovery questions.
- The number before `:` is the metadata address used by `istat` and `icat`.

## Metadata Inspection

```bash
istat -o <OFFSET> "$IMG" <METADATA_ADDRESS>
```

What it does: shows metadata for one file record, including timestamps and file
attributes. Use it when the question asks you to prove when a file existed.

## Artifact Extraction

```bash
icat -o <OFFSET> "$IMG" <METADATA_ADDRESS> > Working/artifact_name
```

Use the metadata addresses returned by your own `fls` command. Do not copy
addresses from another image build.

What it does: copies file content out of the image into your `Working` folder.
`icat` does not automatically know filenames; it needs the metadata address from
`fls`.

## Registry Export Review

The image contains synthetic `.reg` export artifacts. Extract them with `icat`
and inspect their key paths, value names, data, and timestamps:

```bash
less Working/NTUSER_Run_Key.reg
less Working/NTUSER_RecentDocs.reg
less Working/SYSTEM_USBSTOR.reg
```

## Hex Repair

Extract `invoice_cache.bin` into `Working`, open the working copy in a hex
editor, identify the missing signature, overwrite only the damaged bytes, save
the repaired file with a new name, and test it as an archive.

Useful CLI helpers:

```bash
od -An -tx1 -N16 Working/invoice_cache.bin
cp Working/invoice_cache.bin Working/invoice_cache_repaired.zip
printf 'PK' | dd of=Working/invoice_cache_repaired.zip bs=1 seek=0 count=4 conv=notrunc
unzip -l Working/invoice_cache_repaired.zip
unzip -p Working/invoice_cache_repaired.zip recovered_note.txt
```

What they do:
- `od -An -tx1 -N16` displays the first 16 bytes in hex.
- `cp` creates a safe working copy so the original extraction is preserved.
- `printf ... | dd ... conv=notrunc` overwrites only the first four bytes.
- `unzip -l` lists archive contents without extracting them.
- `unzip -p` prints one recovered file to the terminal.

## Flag Normalization

When deriving flags, convert observed evidence into compact lowercase tokens:

- Remove spaces, underscores, hyphens, and file extensions.
- Convert timestamps from `HH:MM:SS` to `hhmmss`.
- Use the evidence field names in the question to decide token order.
