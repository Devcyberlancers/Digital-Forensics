# Machine 05: Registry Shadows

## Story / Scenario

Aarav Mehra's workstation, REG-WS-512, shows signs of suspicious persistence
after removable-media activity. A binary appears in the user's Windows Startup
folder, a Run key points to the same artifact, RecentDocs records payload-related
filenames, USBSTOR shows a SanDisk device, and a damaged archive header appears
inside the evidence image. A deleted closure note suggests the investigator must
correlate filesystem metadata, registry exports, USB activity, and payload repair
before reaching a conclusion.

## Learning Objectives

- Verify forensic image integrity.
- Identify a partition start sector with Sleuth Kit.
- Enumerate filesystem entries with fls.
- Inspect file metadata with istat.
- Extract files from a disk image with icat.
- Interpret Windows Run key persistence.
- Interpret RecentDocs user activity.
- Interpret USBSTOR removable-media evidence.
- Repair a damaged archive header.
- Correlate filesystem, registry, USB, and payload evidence into a final conclusion.

## Student Mission

Use Sleuth Kit directly against `Evidence/Disk/registry_ws512.img`. Recover only
the artifacts needed for the investigation, place working copies in `Working`,
derive answers from evidence observations, and submit answers in the WebApp.
