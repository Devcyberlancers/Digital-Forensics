This folder is intentionally empty. Extract artifacts here yourself with Sleuth Kit commands such as icat.
