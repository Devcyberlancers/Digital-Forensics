Student note
============

Do not analyze pre-expanded or pre-recovered files for this version.
Add Evidence/Disk/pinnacle_ws047.img to Autopsy as 'Disk Image or VM File'.
The deleted documents must be identified and extracted from Autopsy's
Deleted Files view.
