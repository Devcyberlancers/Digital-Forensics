# Case Briefing: The Deleted Evidence

## Incident

On March 14, 2026, Pinnacle Corp marketing analyst Riya Sharma resigned after
being placed on a performance improvement plan. Security footage placed her at
workstation WS-MKT-047 after normal business hours.

The following morning, project files were missing. Management also suspected
that the files had been compressed and transferred before deletion.

## Evidence

- `Evidence/Disk/pinnacle_ws047.img`
- Raw FAT16 forensic image, 64 MB
- SHA-256 manifest under `Hashes/`
- Timezone: Asia/Kolkata

## Mission

1. Verify evidence integrity.
2. Create an Autopsy case and ingest the disk image correctly.
3. Distinguish allocated files from deleted filesystem entries.
4. Recover deleted business documents.
5. Analyze document content and image metadata.
6. Correlate Recycle Bin records with deleted entries.
7. Query Chrome history as SQLite data.
8. Correlate application execution, transfer activity, and deletion.
9. Produce a defensible incident timeline and conclusion.

## Investigation Rule

Do not use pre-recovered copies. Evidence must be located and recovered from
the forensic image. Record the artifact path and tool used for every answer.
