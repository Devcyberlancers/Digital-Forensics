MACHINE 01 - THE DELETED EVIDENCE
=================================

Start here:

1. Open the web app and click Start Investigation.
2. Verify the SHA-256 of Evidence/Disk/pinnacle_ws047.img.
3. Create a new Autopsy case.
4. Add pinnacle_ws047.img as Disk Image or VM File.
5. Do not add this complete folder as Logical Files.
6. Wait for ingest and confirm Deleted Files contains entries.
7. Record findings in Questions/student_answer_log.md.
8. Submit the same findings in the web app.

Important:

- Evidence/Expanded_Files no longer contains pre-recovered answers.
- Deleted documents must be recovered through Autopsy.
- Some files contain embedded marker text, but final flags are derived from
  forensic observations rather than copied directly from one artifact.
- The final question is a capstone analyst conclusion. It requires correlation
  across recovered files, browser history, Prefetch activity, and deletion
  timing.
- The image is a raw FAT16 educational forensic image.
- The case data and identities are fictional.

Files:

- Case_Briefing.md: case story and mission
- Questions/questions.md: challenge questions
- Questions/student_answer_log.md: evidence log
- Hashes/: integrity records
- Tools_Guide/: tool instructions
- Submission/: offline answer sheet
