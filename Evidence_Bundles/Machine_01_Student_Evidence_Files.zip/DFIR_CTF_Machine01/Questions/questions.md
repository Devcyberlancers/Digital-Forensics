# Machine 01: The Deleted Evidence

## Case PC-DFIR-2026-0042



**Questions:** 10

**Derived flags:** 8

**Maximum score:** 100

**Estimated time:** 75-105 minutes



## Required Autopsy Setup



1. Create a new Autopsy case.

2. Select **Add Data Source**.

3. Select **Disk Image or VM File**.

4. Browse to `Evidence/Disk/pinnacle_ws047.img`.

5. Select timezone `Asia/Kolkata`.

6. Enable File Type Identification, Embedded File Extraction, Extension Mismatch

   Detection, Recent Activity, and Keyword Search.

7. Wait for ingest to finish.

8. Confirm that **File Views > Deleted Files** contains deleted entries.



Do not add the complete student folder as Logical Files. Doing that does not

analyze filesystem deletion records and may produce `Deleted Files (0)`.



## Professional Evidence Standard



For every answer, record:



- artifact path;

- tool or feature used;

- observed value;

- corroborating artifact or timestamp;

- interpretation; and

- final submitted answer.



Some recovered files contain embedded marker strings. Do not submit a marker

just because it appears in a file. When a question asks for a derived flag,

build the flag from the forensic observations requested in that question.



## Questions



### Q1 - Evidence Integrity Verification (5 points)



Compute the SHA-256 of `Evidence/Disk/pinnacle_ws047.img`. Compare it with

`Hashes/SHA256SUMS.txt`.



Submit only the first 16 characters.



### Q2 - The Note She Forgot to Delete (5 points)

Locate `Evidence/Expanded_Files/C/Users/riya.sharma/Desktop/case_notes.txt` in Autopsy. Record its full artifact path, the cleanup statement, and the clue that indicates Riya expected an external copy to exist. Treat this as an intent artifact that must later be compared with Chrome history from `Evidence/Expanded_Files/C/Users/riya.sharma/AppData/Local/Google/Chrome/User Data/Default/History`.

Submit a derived flag in this format:

`FLAG{cleanup_<backup_term>_<initials>}`

Use the backup term from the note and Riya's initials.

### Q3 - Deleted Files Triage (10 points)



Use **Deleted Files** to identify the deleted strategy document. Correlate it

with the matching Recycle Bin metadata record.



Submit the original full Windows path.



### Q4 - Recovering the Strategy Document (10 points)

Extract the deleted strategy document using Autopsy. Correlate `D:\Projects\ClientCampaigns\Q3_Campaign_Strategy.docx`, `$Recycle.Bin/S-1-5-21-9842-1847-047/$IA1B2C3.docx`, and the recovered document content. Determine its total Q3 campaign budget, identify the matching Recycle Bin metadata filename, and explain why the document is business-sensitive.

Submit a derived flag in this format:

`FLAG{strategy_<budget_digits>_<recycle_record_id>}`

Use only digits for the budget and lowercase the Recycle Bin record ID without the file extension.

### Q5 - The Confidential Rate Card (10 points)

Recover the deleted PDF rate card from `Evidence/Expanded_Files` and correlate it with `$Recycle.Bin` deletion metadata. Determine the YouTube Pre-roll CPM, cite the document classification, and explain why the artifact supports the suspected business-impact narrative.

Submit a derived flag in this format:

`FLAG{ratecard_<platform>_<cpm>_<classification>}`

Remove spaces and punctuation from the platform value.

### Q6 - Recovered Image Metadata (10 points)

Recover the deleted campaign mockup from `Evidence/Expanded_Files`. Use ExifTool to determine its dimensions, identify the author/artist metadata, and explain how the metadata ties the file back to `Evidence/Expanded_Files/C/Users/riya.sharma/`.

Submit a derived flag in this format:

`FLAG{mockup_<width>x<height>_<artist_first_name>}`

### Q7 - Competitor Intelligence (10 points)

Recover the deleted spreadsheet from `Evidence/Expanded_Files`. Determine the competitor count, the company with the highest estimated Q3 spend, and whether that spend aligns with `D:\Projects\ClientCampaigns\Q3_Campaign_Strategy.docx`.

Submit a derived flag in this format:

`FLAG{competitor_<count>_<top_company_shortname>_<budget_digits>}`

Use the first word of the top company name and the matching budget digits.

### Q8 - Deletion Timeline and Intent (10 points)

Compare all five `$Recycle.Bin` metadata records, including `$Recycle.Bin/S-1-5-21-9842-1847-047/$IA1B2C3.docx`. Recover the additional deleted reminder text file from Deleted Files. Use the deletion-time cluster and the reminder content to determine whether the cleanup appears accidental, routine, or deliberate.

Submit a derived flag in this format:

`FLAG{delete_<count>files_<start_hhmmss>_<end_hhmmss>_<behavior>}`

### Q9 - Browser Transfer Trail (15 points)

Riya's note suggested that a cloud backup already existed. Use Autopsy's browser artifacts to identify the last file-transfer page visited before Gmail activity.

If Autopsy does not show a separate Web History timeline, open the Chrome `History` file at:

`USERS/riya.sharma/APPDATA/LOCAL/GOOGLE/CHROME/User Data/DEFAULT/History`

Use the lower `Application` tab, inspect the `urls` table, and paste the raw Chrome `last_visit_time` value into the Chrome Timestamp Converter shown in the WebApp `Questions` tab if Autopsy only shows the raw value. Do not unlock Evidence Explorer for student solving; that area is instructor reference material.

Identify:

1. the file-transfer service,
2. the exact upload page URL,
3. the local visit time,
4. whether this activity occurred before the later deletion window.

Submit a derived flag in this format:

`FLAG{transfer_<service>_<hhmmss>_before_gmail}`

### Q10 - Capstone Analyst Conclusion (15 points)

Correlate `WINRAR.EXE` Prefetch execution records, Chrome History from Autopsy's `Application` tab or parsed browser artifacts, recovered business documents such as `D:\Projects\ClientCampaigns\Q3_Campaign_Strategy.docx`, and the `$Recycle.Bin` deletion window. Identify the executable that indicates compression, the transfer service that immediately preceded Gmail activity, and the deletion behavior that followed.

Write a short analyst conclusion answering whether the evidence supports deliberate transfer followed by cleanup. Then submit a derived flag in this format:

`FLAG{<compression_tool>_<transfer_service>_<deletion_behavior>_supported}`
