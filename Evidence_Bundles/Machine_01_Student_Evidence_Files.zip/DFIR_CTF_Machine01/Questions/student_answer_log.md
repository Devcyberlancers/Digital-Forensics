# Machine 01 Student Investigation Log

Use this log while working. The WebApp only validates final answers, but your
professional finding should preserve how each answer was derived.

| Question | Artifact path | Tool / feature | Observation | Corroboration | Interpretation | Submitted answer |
|---|---|---|---|---|---|---|
| Q1 |  |  |  |  |  |  |
| Q2 |  |  |  |  |  |  |
| Q3 |  |  |  |  |  |  |
| Q4 |  |  |  |  |  |  |
| Q5 |  |  |  |  |  |  |
| Q6 |  |  |  |  |  |  |
| Q7 |  |  |  |  |  |  |
| Q8 |  |  |  |  |  |  |
| Q9 |  |  |  |  |  |  |
| Q10 |  |  |  |  |  |  |

## Final Timeline

Record the supported activity sequence here:

1.
2.
3.
4.
5.

## Analyst Conclusion

Write a short conclusion explaining whether the evidence supports accidental
loss, routine cleanup, or deliberate data transfer followed by cleanup. Cite at
least three artifacts from your log.
