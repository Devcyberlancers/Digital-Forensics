# Machine 01 Hints

Use these only after making a genuine attempt.

## Q1
Use `sha256sum` on Linux or `Get-FileHash -Algorithm SHA256` in PowerShell.

## Q2
The note is allocated under the suspect's Desktop directory.

## Q3
Deleted Files identifies the file. The matching `$I`-style record under
`$Recycle.Bin` preserves the original Windows path.

## Q4
Right-click the deleted file and select **Extract File(s)**. Do not use
`Expanded_Files`.

## Q5
Filter deleted entries by PDF type, recover the file, then inspect its footer.

## Q6
Run `exiftool recovered_file.png` and inspect image dimensions plus the Artist
field.

## Q7
Use the workbook rows to count competitors and compare the estimated Q3 spend
column.

## Q8
Five deletion records occur within two seconds. Recover the deleted reminder
text file itself to interpret the deletion behavior.

## Q9
Focus on evening browser activity. Compare Drive, WeTransfer, and Gmail
entries, then choose the final file-transfer page before Gmail.

## Q10
Order WINRAR execution, cloud-transfer visits, and the 21:15 deletion window.
