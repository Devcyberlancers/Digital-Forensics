# Machine 01 Tool Guide

## Autopsy

Create a case and use:

`Add Data Source > Disk Image or VM File > pinnacle_ws047.img`

Recommended ingest modules:

- File Type Identification
- Embedded File Extraction
- Extension Mismatch Detector
- Recent Activity
- Keyword Search

Useful locations:

- `Data Sources`: allocated filesystem tree
- `File Views > Deleted Files`: deleted directory entries
- `File Metadata`: allocation state, size, timestamps, parent path
- `Text > Extracted Text`: readable parsed content from documents/workbooks
- `Extract File(s)`: recover selected artifacts

If Deleted Files shows zero, confirm that the `.img` file itself was added as
a disk image. Adding the student directory as Logical Files cannot expose
filesystem deletion records.

## Hashing

Linux:

```bash
sha256sum Evidence/Disk/pinnacle_ws047.img
```

PowerShell:

```powershell
Get-FileHash Evidence\Disk\pinnacle_ws047.img -Algorithm SHA256
```

## ExifTool

```bash
exiftool campaign_mockup_v3.png
```

Record image dimensions and artist/author fields. The final answer should
explain what the metadata proves, not only what value was found.

## Autopsy Browser History and Keyword Search

Autopsy can parse browser artifacts during ingest, but in this teaching image it
may expose Chrome History directly through the file viewer instead of a separate
timeline. For transfer-trail tasks:

1. Open `USERS/riya.sharma/APPDATA/LOCAL/GOOGLE/CHROME/User Data/DEFAULT`.
2. Select the `History` file.
3. In the lower viewer, open `Application`.
4. Select the `urls` table.
5. Compare cloud or transfer domains such as `drive.google.com`,
   `wetransfer.com`, and `mail.google.com`.
6. If Autopsy shows a raw Chrome timestamp, paste it into the WebApp's Chrome
   Timestamp Converter in the WebApp `Questions` tab.
7. Record the final file-transfer URL before Gmail activity.
8. Compare its local time with the deletion window from Recycle Bin metadata.

This teaches browser artifact interpretation without requiring students to
write SQL queries or code against Chrome's History database.

## LibreOffice / Document Viewers

Open only copies extracted to a recovery directory. Keep the forensic image
read-only and never edit evidence in place.

## Derived Flag Standard

When a question asks for a derived flag, build it from the observations named
in that question. Use lowercase values, remove spaces unless the question
states otherwise, and preserve the exact `FLAG{...}` wrapper.
