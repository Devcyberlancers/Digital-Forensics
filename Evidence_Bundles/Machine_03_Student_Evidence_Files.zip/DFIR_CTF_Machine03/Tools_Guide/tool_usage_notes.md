# Machine 03 Tools Guide

## Core Workflow

This machine is solved by reading offline evidence exports. You do not need to run live USBRip against the system; the USBRip history report is already provided as a forensic export.

Recommended order:

1. Verify the evidence hash.
2. Review USBRip history for device, serial, connection, and removal times.
3. Confirm USBRip values in the USBSTOR export.
4. Review copy logs to prove file movement.
5. Review Recent LNK exports for USB target paths.
6. Review ShellBags for opened USB folders.
7. Review Prefetch-style records for 7Z archive creation and Explorer access.
8. Build a timeline and IOC summary.

## USBRip Report Review

Path:

```bash
Evidence/Expanded_Files/Tools/USBRip/usbrip_history_report.txt
```

Look for:
- Host and user.
- Device name.
- Vendor and product.
- Serial number.
- Connected and disconnected timestamps.
- Volume letter and volume label.

## USBSTOR Confirmation

Path:

```bash
Evidence/Expanded_Files/C/Windows/System32/config/USBSTOR_Device_History.txt
```

Use this to confirm:
- Device friendly name.
- Vendor/product string.
- Serial number.
- Volume label.
- First install, last connected, and last removal times.

## Copy Log Interpretation

Path:

```bash
Evidence/Expanded_Files/D/Clients/Contracts/copy_activity_log.csv
```

Important fields:
- `action`: distinguishes `archive-created` from `copied`.
- `source`: original file location.
- `destination`: USB or staging destination.
- `category`: sensitivity classification.

For Q4, count copied confidential items and identify the USB volume label.

## Recent LNK Interpretation

Path:

```bash
Evidence/Expanded_Files/C/Users/arjun.nair/AppData/Roaming/Microsoft/Windows/Recent/
```

Look for:
- Target path on drive `E:`.
- Target filename.
- Created/accessed timestamps.

LNK artifacts help prove that copied USB files were later accessed.

## ShellBag Interpretation

Path:

```bash
Evidence/Expanded_Files/C/Users/arjun.nair/AppData/Local/Microsoft/Windows/Shell/ShellBags_USB_Folders.txt
```

ShellBags show folders viewed in Explorer. Use the deepest folder and the view time for Q6.

## Prefetch-Style Evidence

Paths:

```bash
Evidence/Expanded_Files/C/Windows/Prefetch/7Z.EXE-98A7B6C5.pf
Evidence/Expanded_Files/C/Windows/Prefetch/EXPLORER.EXE-41A2B3C4.pf
```

Use:
- `7Z.EXE` to support archive creation.
- `EXPLORER.EXE` to support folder browsing.

## Flag Normalization

When deriving flags:

- Convert to lowercase.
- Remove spaces, underscores, hyphens, periods, and file extensions unless the question format says otherwise.
- Convert times from `HH:MM:SS` to `HHMM`.
- Use the exact field order given in the question.

Examples:

- `Kingston` -> `kingston`
- `DataTraveler_3.0` -> `datatraveler`
- `ORBIT_EXPORT` -> `orbitexport`
- `Client_Master_Agreement.pdf` -> `clientmasteragreement`
- `19:03:22` -> `1903`
