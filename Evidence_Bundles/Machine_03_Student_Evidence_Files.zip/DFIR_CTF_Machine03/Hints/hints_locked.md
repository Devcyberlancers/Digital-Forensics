# Hints

Start with USBRip, confirm with USBSTOR, then move to copy logs, LNK files, ShellBags, Prefetch-style records, and timeline correlation.
