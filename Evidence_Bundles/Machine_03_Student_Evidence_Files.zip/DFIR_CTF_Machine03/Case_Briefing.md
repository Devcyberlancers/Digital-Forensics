# Machine 03: The USB Drop

Case Number: ORB-DFIR-2026-0217

## Story / Scenario

Orbital Retail's legal operations team reported that confidential client contract files may have been copied to removable media from workstation ORB-WS-221. The user under review is Arjun Nair, a product analyst with access to client agreement folders. Security did not seize a physical USB device, so the investigation depends on host artifacts: USBRip history, USBSTOR registry-style exports, Recent shortcut traces, ShellBag folder-access records, copy activity logs, and Prefetch-style application execution records.

The investigation goal is to prove whether a Kingston USB device was connected, whether it can be tied to a specific serial number and volume label, what files were staged or copied, whether the user browsed the USB destination, and whether the sequence supports removable-media exfiltration.

## Learning Objectives

- Verify evidence integrity before analysis.
- Use USBRip-style history to identify a removable USB device.
- Corroborate USBRip observations with Windows USBSTOR evidence.
- Interpret USB serial number, vendor/product, volume letter, and volume label.
- Review copy logs to identify data movement to removable media.
- Interpret Recent LNK target paths and access times.
- Interpret ShellBag folder access for USB directory browsing.
- Correlate Prefetch-style 7Z and Explorer activity.
- Build an IOC summary from device, serial, volume, and sensitive folder evidence.
- Reconstruct a final USB exfiltration timeline.

## Student Mission

Use the supplied evidence to determine whether Arjun Nair copied confidential client files to a USB drive. Do not search for ready-made flags. Each answer is derived from observed values such as vendor, product, serial, volume label, file count, paths, timestamps, folder names, and event order.
