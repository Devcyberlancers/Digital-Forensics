DFIR CTF Machine 03 - The USB Drop

Beginner-friendly USB/removable-media exfiltration investigation.

Start:
1. Open the WebApp and click Start Investigation.
2. Download or extract the student evidence.
3. Use Kali tools to review USBRip, USBSTOR, copy logs, Recent LNK files, ShellBags, Prefetch-style records, and the timeline.
4. Submit derived answers in the WebApp.
