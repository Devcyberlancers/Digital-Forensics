# Machine 03: The USB Drop - Investigation Questions

## Case Number: ORB-DFIR-2026-0217

## Story / Scenario

Arjun Nair is suspected of copying confidential client contracts to a removable USB drive. Use USBRip, USBSTOR, copy logs, LNK files, ShellBags, Prefetch-style records, and timeline artifacts to derive each answer.

## Learning Objectives

- Verify evidence integrity.
- Review USBRip device history.
- Corroborate USB device details with USBSTOR.
- Analyze Recent LNK target paths.
- Interpret ShellBag folder access.
- Review copy activity logs.
- Correlate Prefetch-style 7Z and Explorer activity.
- Build USB IOC and timeline conclusions.

> Total Questions: 10  
> Total Flags: 9  
> Estimated Time: 40-60 minutes  
> Flag Format: `FLAG{text_with_underscores}`

### Q1 - Evidence Integrity Verification (5 pts)
**Difficulty:** Easy
**Tool:** sha256sum / manifest comparison

Compute the SHA-256 hash of `Evidence/Disk/usb_ws221.vhd`, compare it with `Hashes/SHA256SUMS.txt`, and submit only `<first_16_sha256_chars>`.

### Q2 - USB Device Attribution (5 pts)
**Difficulty:** Easy
**Tool:** USBRip + USBSTOR

Use USBRip and USBSTOR evidence to identify the vendor, product family, and volume label. Submit `FLAG{usb_<vendor>_<productfamily>_<volumelabel>}`.

### Q3 - Serial Corroboration (5 pts)
**Difficulty:** Easy
**Tool:** USBRip + USBSTOR

Confirm the USB serial number in both USBRip and USBSTOR. Submit `FLAG{serial_<serial>_confirmed}`.

### Q4 - Copy Activity (5 pts)
**Difficulty:** Easy
**Tool:** CSV review

Review `copy_activity_log.csv`. Count copied confidential items and identify the destination volume label. Submit `FLAG{copied_<count>_<category>_<volumelabel>}`.

### Q5 - Recent File Shortcut Trail (8 pts)
**Difficulty:** Medium
**Tool:** LNK target review

Inspect Recent `.lnk` artifacts. Use the drive letter, target filename stem, and access time to derive `FLAG{lnk_<driveletter>_<targetstem>_<hhmm>}`.

### Q6 - Shellbag Folder Access (8 pts)
**Difficulty:** Medium
**Tool:** Shellbag export

Inspect `ShellBags_USB_Folders.txt`. Use the deepest USB folder and Explorer view time to derive `FLAG{shellbag_<folder_token>_<hhmm>}`.

### Q7 - Connection Window (8 pts)
**Difficulty:** Medium
**Tool:** USBRip + USBSTOR

Use USBRip and USBSTOR timestamps to derive the USB connection window. Submit `FLAG{usb_window_<firstconnect_hhmm>_<lastremoval_hhmm>}`.

### Q8 - Archive Staging (8 pts)
**Difficulty:** Medium
**Tool:** Copy log + 7Z Prefetch-style record

Use the copy log and 7Z Prefetch-style artifact to identify the staged archive, creation time, and tool. Submit `FLAG{archive_<archivestem>_<hhmm>_<tool>}`.

### Q9 - USB IOC Summary (8 pts)
**Difficulty:** Medium
**Tool:** IOC correlation

Correlate USBRip, USBSTOR, copy log, LNK, and ShellBag evidence. Submit `FLAG{ioc_<vendor>_<serial>_<volumelabel>_<sensitivefolder>}`.

### Q10 - USB Timeline Capstone (12 pts)
**Difficulty:** Hard
**Tool:** Timeline correlation

Build the ordered chain: USB connect -> archive created -> files copied -> LNK access -> shellbag folder opened -> USB removed. Submit `FLAG{usbtrail_<connect>_<archive>_<firstcopy>_<lnkaccess>_<shellbag>_<removal>}`.
